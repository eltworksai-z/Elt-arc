"""Create all layer tables from their tables.yml (run once at deploy).

Delta tables (L1, L2) are created via Spark; Postgres tables (L3) via psycopg2.
This is a thin orchestrator around ddl/generate_ddl.py output.
"""
from __future__ import annotations

import subprocess
import sys


DELTA = ["src/l1/conf/tables.yml", "src/l2/conf/tables.yml"]
POSTGRES = ["src/l3/conf/tables.yml"]


def gen(path: str, dialect: str) -> str:
    out = subprocess.check_output(
        [sys.executable, "ddl/generate_ddl.py", path, "--dialect", dialect])
    return out.decode()


if __name__ == "__main__":
    print("-- DELTA (run on Spark / Databricks SQL) --")
    for p in DELTA:
        print(gen(p, "delta"))
    print("-- POSTGRES (run via psql) --")
    for p in POSTGRES:
        print(gen(p, "postgres"))
