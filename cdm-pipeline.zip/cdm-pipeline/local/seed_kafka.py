"""Produce sample raw events to Kafka for a local L1 -> L2 -> L3 run.

    pip install kafka-python
    python local/seed_kafka.py

Demonstrates the enrichment timing cases from the design:
  - ppt before ppb (different batch)
  - ppt + ppb same batch
  - ppt update
"""
import json
import time

from kafka import KafkaProducer

p = KafkaProducer(
    bootstrap_servers="localhost:9092",
    value_serializer=lambda v: json.dumps(v).encode(),
    key_serializer=lambda k: k.encode(),
)


def send(topic, key, payload):
    p.send(topic, key=key, value=payload)
    p.flush()
    print("sent", topic, key, payload)


# 1. ppt A1 first (source before target)
send("raw.ppt", "A1", {"pk": "A1", "weight": 10.0, "grade": "X",
                        "category": "c1", "event_time": "2026-01-01 10:00:00"})
time.sleep(1)

# 2. ppb A1 later -> should enrich to weight 10 from the table
send("raw.ppb", "A1", {"pk": "A1", "qty": 5, "batch_no": "B7",
                       "customer_id": "C9", "product_id": "X4",
                       "event_time": "2026-01-01 10:05:00"})
time.sleep(1)

# 3. ppt + ppb same pk B2 together (same-batch case)
send("raw.ppt", "B2", {"pk": "B2", "weight": 20.0, "grade": "Y",
                       "category": "c2", "event_time": "2026-01-01 10:06:00"})
send("raw.ppb", "B2", {"pk": "B2", "qty": 7, "batch_no": "B8",
                       "customer_id": "C1", "product_id": "X1",
                       "event_time": "2026-01-01 10:06:00"})
time.sleep(1)

# 4. ppt A1 UPDATE -> existing ppb A1 should re-enrich to 99
send("raw.ppt", "A1", {"pk": "A1", "weight": 99.0, "grade": "Z",
                       "category": "c1", "event_time": "2026-01-01 11:00:00"})

# invoice: map-only, no enrichment
send("raw.invoice", "INV1", {"id": "INV1", "amount": 42.5, "currency": "usd",
                             "created": "2026-01-01 09:00:00"})
print("done")
