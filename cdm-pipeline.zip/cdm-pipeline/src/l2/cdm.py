"""L2 CDM engine (Delta).

Per micro-batch, in fixed order:
  1. map each incoming row to CDM shape (entity_type, entity_id, event_time,
     attributes) using the mapping files
  2. dedupe newest per (entity_type, entity_id)
  3. SCD1 MERGE all entities into cdm.entities (newest-wins guard)
  4. for each enrichment source present, MERGE its provided fields onto the
     target rows' attributes (reads committed table, so same-batch works
     because step 3 committed the sources first)

attributes is a VARIANT; enrichment patches single keys with object_insert so
the rest of the object is preserved.
"""
from __future__ import annotations

from typing import Dict, List

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.window import Window

from src.common.enrich import EnrichPlan
from src.common.expr_builder import build_row_select
from src.common.mapping import MappingFile


def map_entity(batch_df: DataFrame, mf: MappingFile) -> DataFrame:
    """Map one entity_type's incoming rows to CDM shape.

    Returns columns: entity_type, entity_id, event_time, attributes (json str),
    plus the raw mapped columns (kept so enrichment join keys are available).
    """
    select_exprs = build_row_select(mf)
    mapped = batch_df.selectExpr(*select_exprs)

    # attributes = all row-derived targets as a JSON object
    attr_targets = [m.target for m in mf.plain_and_source()]
    struct_cols = ", ".join(f"'{t}', {t}" for t in attr_targets)
    mapped = mapped.withColumn("attributes", F.expr(f"to_json(named_struct({struct_cols}))"))

    mapped = (mapped
              .withColumn("entity_type", F.lit(mf.target_entity))
              .withColumn("entity_id", F.col(mf.key).cast("string"))
              .withColumn("event_time", F.col(mf.event_time)))
    return mapped


def dedupe_latest(df: DataFrame, keys: List[str], order_by: str) -> DataFrame:
    w = Window.partitionBy(*keys).orderBy(F.col(order_by).desc())
    return (df.withColumn("_rn", F.row_number().over(w))
              .filter(F.col("_rn") == 1)
              .drop("_rn"))


def scd1_merge(spark: SparkSession, batch: DataFrame, table: str,
               order_by: str) -> None:
    """SCD1 upsert on (entity_type, entity_id), newest event_time wins."""
    view = "l2_batch_scd"
    batch.select("entity_type", "entity_id", "event_time", "attributes",
                 F.current_timestamp().alias("ingested_at")).createOrReplaceTempView(view)
    spark.sql(f"""
        MERGE INTO {table} t
        USING {view} s
        ON  t.entity_type = s.entity_type AND t.entity_id = s.entity_id
        WHEN MATCHED AND s.{order_by} > t.{order_by}
            THEN UPDATE SET *
        WHEN NOT MATCHED
            THEN INSERT *
    """)


def enrich_merge(spark: SparkSession, table: str, plan: EnrichPlan,
                 batch: DataFrame, order_by: str) -> None:
    """Patch target attributes from source rows, scoped to pks changed this batch.

    One MERGE per (source_entity, join key) group -> all fields of that group in
    a single object_insert chain.
    """
    changed_view = "l2_changed_sources"
    batch.select("entity_type", "entity_id").createOrReplaceTempView(changed_view)

    for (source_entity, on), edges in plan.grouped_lookups().items():
        target_types = sorted({e.target_entity for e in edges})
        in_list = ", ".join(f"'{t}'" for t in target_types)

        # build a chained object_insert applying every field in this group
        set_expr = "t.attributes"
        for e in edges:
            transform = e.source_field
            # pull provided field out of source attributes json
            val = f"from_json(s.attributes,'map<string,string>')['{e.source_field}']"
            set_expr = (f"object_insert({set_expr}, '{e.target_field}', "
                        f"{val}, true)")

        # newest source per join key, from the committed table
        spark.sql(f"""
            MERGE INTO {table} t
            USING (
                SELECT entity_id AS join_key, attributes,
                       ROW_NUMBER() OVER (PARTITION BY entity_id
                                          ORDER BY {order_by} DESC) AS rn
                FROM {table}
                WHERE entity_type = '{source_entity}'
                  AND entity_id IN (
                      SELECT entity_id FROM {changed_view}
                      WHERE entity_type = '{source_entity}')
            ) s
            ON s.rn = 1
               AND t.entity_id = s.join_key
               AND t.entity_type IN ({in_list})
            WHEN MATCHED THEN UPDATE SET t.attributes = {set_expr}
        """)


def process_batch(spark: SparkSession, batch_df: DataFrame,
                  mapping_files: Dict[str, MappingFile], plan: EnrichPlan,
                  table: str, order_by: str) -> None:
    # 1. map every entity type present, union into one CDM frame
    frames: List[DataFrame] = []
    for etype, mf in mapping_files.items():
        sub = batch_df.filter(F.col("entity_type") == etype)
        if sub.isEmpty():
            continue
        frames.append(map_entity(sub, mf).select(
            "entity_type", "entity_id", "event_time", "attributes"))
    if not frames:
        return
    cdm = frames[0]
    for f in frames[1:]:
        cdm = cdm.unionByName(f)

    # 2. dedupe newest per (entity_type, entity_id)
    cdm = dedupe_latest(cdm, ["entity_type", "entity_id"], "event_time")
    cdm.cache()

    # 3. SCD1 upsert (commits sources before enrichment reads them)
    scd1_merge(spark, cdm, table, order_by)

    # 4. enrich targets from committed sources, scoped to changed pks
    if plan.edges:
        enrich_merge(spark, table, plan, cdm, order_by)

    cdm.unpersist()
