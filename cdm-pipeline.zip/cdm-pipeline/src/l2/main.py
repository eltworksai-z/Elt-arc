"""L2 CDM (Delta) streaming job.

Reads bronze (valid rows), maps + enriches, SCD1-upserts into cdm.entities.

Run:
  python -m src.l2.main --conf src/l2/conf
"""
from __future__ import annotations

import argparse
from pathlib import Path

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from src.common.enrich import build_plan
from src.common.io import load_mapping_files

from .cdm import process_batch
from .config import load_l2, load_registry


def build_stream(spark: SparkSession, conf_dir: str) -> None:
    conf_dir = str(conf_dir)
    cfg = load_l2(conf_dir)
    load_registry(conf_dir)  # validated, available if needed
    mapping_files = load_mapping_files(Path(conf_dir) / "entities")
    plan = build_plan(mapping_files)  # validates from<->provides, fails fast

    reader = (spark.readStream.format(cfg.source.format)
              .option("readChangeFeed", str(cfg.source.read_change_feed).lower()))
    src = reader.table(cfg.source.catalog_table)
    if cfg.source.filter:
        src = src.filter(F.expr(cfg.source.filter))
    if cfg.watermark:
        src = src.withWatermark(cfg.watermark.column, cfg.watermark.delay)

    order_by = cfg.scd.order_by
    table = cfg.scd.table

    def run(batch_df: DataFrame, batch_id: int) -> None:
        process_batch(spark, batch_df, mapping_files, plan, table, order_by)

    (src.writeStream
        .foreachBatch(run)
        .option("checkpointLocation", cfg.checkpoint)
        .start()
        .awaitTermination())


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--conf", default="src/l2/conf")
    args = ap.parse_args()
    spark = SparkSession.builder.appName("l2-cdm").getOrCreate()
    build_stream(spark, args.conf)


if __name__ == "__main__":
    main()
