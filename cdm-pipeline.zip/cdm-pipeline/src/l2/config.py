"""L2 config + registry models."""
from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Literal, Optional

from pydantic import BaseModel

from src.common.io import load_yaml
from src.common.tables import TableSpec


class Source(BaseModel):
    format: str
    catalog_table: str
    read_change_feed: bool = False
    filter: Optional[str] = None


class Watermark(BaseModel):
    column: str
    delay: str


class SCD(BaseModel):
    mode: Literal["scd1"] = "scd1"
    table: str
    business_key: List[str]
    order_by: str


class Sink(BaseModel):
    catalog_table: str


class L2Config(BaseModel):
    layer: str
    source: Source
    watermark: Optional[Watermark] = None
    scd: SCD
    sink: Sink
    registry: str
    tables: str
    entities_dir: str
    checkpoint: str


class RegistryEntry(BaseModel):
    type: str
    role: Literal["source", "target", "plain"] = "plain"
    mapping: str


class Registry(BaseModel):
    version: int = 1
    entities: List[RegistryEntry]

    def types(self) -> List[str]:
        return [e.type for e in self.entities]


def load_l2(conf_dir: str | Path) -> L2Config:
    return L2Config(**load_yaml(Path(conf_dir) / "l2.yml"))


def load_registry(conf_dir: str | Path) -> Registry:
    return Registry(**load_yaml(Path(conf_dir) / "registry.yml"))


def load_tables(conf_dir: str | Path) -> TableSpec:
    return TableSpec(**load_yaml(Path(conf_dir) / "tables.yml"))
