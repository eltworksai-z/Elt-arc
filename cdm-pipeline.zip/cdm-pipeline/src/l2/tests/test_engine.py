"""Tests for the shared engine (no Spark needed)."""
import pytest

from src.common.enrich import build_plan
from src.common.expr_builder import build_row_select
from src.common.mapping import MappingFile


def _ppt():
    return MappingFile(
        target_entity="ppt", source="s", key="pk", event_time="event_ts",
        mappings=[
            {"target": "pk", "expr": "pk", "required": True},
            {"target": "complex_weight", "expr": "CAST(weight AS DOUBLE)", "provides": True},
            {"target": "grade", "expr": "grade", "provides": True},
            {"target": "event_ts", "expr": "to_timestamp(event_time)", "required": True},
        ],
    )


def _ppb():
    return MappingFile(
        target_entity="ppb", source="s", key="pk", event_time="event_ts",
        mappings=[
            {"target": "pk", "expr": "pk", "required": True},
            {"target": "qty", "expr": "CAST(qty AS INT)"},
            {"target": "event_ts", "expr": "to_timestamp(event_time)", "required": True},
            {"target": "complex_weight",
             "from": {"entity": "ppt", "field": "complex_weight", "on": "pk"},
             "transforms": ["round2"]},
            {"target": "grade",
             "from": {"entity": "ppt", "field": "grade", "on": "pk"}},
        ],
    )


def test_row_select_excludes_enriched():
    exprs = build_row_select(_ppb())
    joined = " ".join(exprs)
    assert "qty" in joined
    assert "complex_weight" not in joined  # enriched -> not a row select
    assert "grade AS grade" not in joined


def test_struct_and_dotted():
    mf = MappingFile(
        target_entity="x", source="s", key="id", event_time="ts",
        mappings=[
            {"target": "id", "expr": "id"},
            {"target": "ts", "expr": "ts"},
            {"target": "props", "type": "struct", "fields": [
                {"target": "tier", "expr": "raw_tier"},
                {"target": "addr", "type": "struct", "fields": [
                    {"target": "city", "expr": "addr.city"}]},
            ]},
            {"target": "audit.created_by", "expr": "created_by"},
            {"target": "audit.updated_by", "expr": "updated_by"},
        ],
    )
    exprs = build_row_select(mf)
    j = " ".join(exprs)
    assert "struct(" in j
    assert "AS props" in j
    assert "AS audit" in j  # dotted folded into one struct


def test_transforms_applied():
    mf = MappingFile(
        target_entity="x", source="s", key="id", event_time="ts",
        mappings=[
            {"target": "id", "expr": "id"},
            {"target": "ts", "expr": "ts"},
            {"target": "name", "expr": "name", "transforms": ["trim", "lowercase"]},
        ],
    )
    j = " ".join(build_row_select(mf))
    assert "lower(trim(name))" in j


def test_enrich_plan_valid():
    plan = build_plan({"ppt": _ppt(), "ppb": _ppb()})
    assert set(plan.source_entities) == {"ppt"}
    assert set(plan.target_entities) == {"ppb"}
    # same source + key -> one lookup group with two fields
    groups = plan.grouped_lookups()
    assert len(groups) == 1
    (src, on), edges = next(iter(groups.items()))
    assert src == "ppt" and on == "pk"
    assert {e.target_field for e in edges} == {"complex_weight", "grade"}


def test_enrich_plan_rejects_unprovided():
    bad = MappingFile(
        target_entity="ppb", source="s", key="pk", event_time="event_ts",
        mappings=[
            {"target": "pk", "expr": "pk"},
            {"target": "event_ts", "expr": "event_time"},
            {"target": "missing",
             "from": {"entity": "ppt", "field": "not_provided", "on": "pk"}},
        ],
    )
    with pytest.raises(ValueError, match="does not mark"):
        build_plan({"ppt": _ppt(), "ppb": bad})


def test_mapping_rejects_expr_and_from():
    with pytest.raises(ValueError, match="both"):
        MappingFile(
            target_entity="x", source="s", key="id", event_time="ts",
            mappings=[
                {"target": "id", "expr": "id"},
                {"target": "ts", "expr": "ts"},
                {"target": "bad", "expr": "x",
                 "from": {"entity": "y", "field": "z", "on": "id"}},
            ],
        )
