"""Derive the enrichment wiring from a set of mapping files.

Given all entities' MappingFiles, work out:
  - which entity_types are enrichment SOURCES (have `provides` fields)
  - which are TARGETS (have `from:` entries) and what they pull
  - validate every `from:` points at a real `provides` field (fail fast)

The result feeds the layer executors (Delta MERGE / Postgres UPDATE...FROM).
Grouping: enrichments that share (source_entity, join key) are one lookup.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Tuple

from .mapping import MappingFile


@dataclass
class EnrichEdge:
    target_entity: str        # e.g. ppb
    target_field: str         # e.g. complex_weight (name written into attributes)
    source_entity: str        # e.g. ppt
    source_field: str         # e.g. complex_weight (the provided field)
    on: str                   # join key present on both sides
    transforms: List[str]     # applied to the pulled value


@dataclass
class EnrichPlan:
    edges: List[EnrichEdge] = field(default_factory=list)

    @property
    def source_entities(self) -> List[str]:
        return sorted({e.source_entity for e in self.edges})

    @property
    def target_entities(self) -> List[str]:
        return sorted({e.target_entity for e in self.edges})

    def edges_for_target(self, entity: str) -> List[EnrichEdge]:
        return [e for e in self.edges if e.target_entity == entity]

    def edges_for_source(self, entity: str) -> List[EnrichEdge]:
        return [e for e in self.edges if e.source_entity == entity]

    def grouped_lookups(self) -> Dict[Tuple[str, str], List[EnrichEdge]]:
        """(source_entity, on) -> edges. Same source+key => one join, many fields."""
        groups: Dict[Tuple[str, str], List[EnrichEdge]] = {}
        for e in self.edges:
            groups.setdefault((e.source_entity, e.on), []).append(e)
        return groups


def build_plan(mapping_files: Dict[str, MappingFile]) -> EnrichPlan:
    """mapping_files: entity_type -> MappingFile. Validates provides<->from."""
    provided: Dict[str, set] = {
        etype: set(mf.provided_fields()) for etype, mf in mapping_files.items()
    }

    plan = EnrichPlan()
    for etype, mf in mapping_files.items():
        for m in mf.enriched():
            src = m.from_.entity
            fld = m.from_.field
            if src not in mapping_files:
                raise ValueError(
                    f"{etype}.{m.target}: from.entity '{src}' has no mapping file"
                )
            if fld not in provided.get(src, set()):
                raise ValueError(
                    f"{etype}.{m.target}: pulls '{fld}' from '{src}', but '{src}' "
                    f"does not mark '{fld}' as provides:true"
                )
            plan.edges.append(
                EnrichEdge(
                    target_entity=etype,
                    target_field=m.into_attribute or m.target,
                    source_entity=src,
                    source_field=fld,
                    on=m.from_.on,
                    transforms=m.transforms,
                )
            )
    return plan
