"""Small shared helpers: YAML loading, env expansion, mapping-file loading."""
from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Dict

import yaml

from .mapping import MappingFile

_ENV = re.compile(r"\$\{([A-Z0-9_]+)\}")


def _expand_env(obj):
    if isinstance(obj, str):
        return _ENV.sub(lambda m: os.environ.get(m.group(1), m.group(0)), obj)
    if isinstance(obj, dict):
        return {k: _expand_env(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_expand_env(v) for v in obj]
    return obj


def load_yaml(path: str | Path) -> dict:
    with open(path) as f:
        return _expand_env(yaml.safe_load(f))


def load_mapping_files(entities_dir: str | Path) -> Dict[str, MappingFile]:
    """Load every entities/*.yml -> {entity_type: MappingFile}. Fails fast."""
    out: Dict[str, MappingFile] = {}
    for p in sorted(Path(entities_dir).glob("*.yml")):
        mf = MappingFile(**load_yaml(p))
        out[mf.target_entity] = mf
    return out
