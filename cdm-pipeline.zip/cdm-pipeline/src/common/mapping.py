"""Shared mapping models used by L2 and L3.

A mapping file describes how one entity_type is produced. Each entry in
`mappings` is a target field with one of three origins:

  - plain      : has `expr`                      -> value from the current row
  - source     : has `expr` + `provides: true`   -> value from row, ALSO exposed
                                                    to other entities for enrichment
  - enriched   : has `from:`                      -> value pulled from another
                                                    entity (a `provides` field),
                                                    then optionally `transforms`

Nested targets (struct/map/array) reuse the same `Mapping` shape recursively.
"""
from __future__ import annotations

from typing import List, Literal, Optional

from pydantic import BaseModel, model_validator


class FromSpec(BaseModel):
    """Enrichment source reference: pull `field` from `entity`, matched `on` a key."""
    entity: str
    field: str
    on: str                       # join key (a target name in both entities)

    @model_validator(mode="before")
    @classmethod
    def _fix_yaml_on(cls, data):
        # YAML 1.1 parses a bare `on:` key as boolean True; map it back.
        if isinstance(data, dict) and True in data and "on" not in data:
            on_val = data[True]
            data = {k: v for k, v in data.items() if k is not True}
            data["on"] = on_val
        return data


class Mapping(BaseModel):
    target: str
    expr: Optional[str] = None
    type: Literal["scalar", "struct", "map", "array"] = "scalar"
    fields: Optional[List["Mapping"]] = None      # struct only
    key_type: Optional[str] = None                # map only
    value_type: Optional[str] = None              # map only
    element_type: Optional[str] = None            # array only
    from_: Optional[FromSpec] = None              # enriched field (yaml key: `from`)
    provides: bool = False                        # source field exposed for enrichment
    transforms: List[str] = []
    required: bool = False
    on_missing: Optional[Literal["skip", "error", "null"]] = None
    pii: bool = False
    into_attribute: Optional[str] = None          # where an enriched value lands

    model_config = {"populate_by_name": True}

    @model_validator(mode="before")
    @classmethod
    def _alias_from(cls, data):
        # allow YAML `from:` -> model field `from_`
        if isinstance(data, dict) and "from" in data and "from_" not in data:
            data = dict(data)
            data["from_"] = data.pop("from")
        return data

    @model_validator(mode="after")
    def _check(self):
        if self.type == "struct":
            # None = omitted (user error); [] = builder intermediate (allowed)
            if self.fields is None:
                raise ValueError(f"{self.target}: struct requires `fields`")
        elif self.fields is not None:
            raise ValueError(f"{self.target}: only struct may declare `fields`")

        origins = sum(bool(x) for x in (self.expr, self.from_, self.type == "struct"))
        if origins == 0:
            raise ValueError(
                f"{self.target}: needs one of `expr`, `from`, or struct `fields`"
            )
        if self.expr and self.from_:
            raise ValueError(f"{self.target}: cannot have both `expr` and `from`")
        if self.provides and not self.expr:
            raise ValueError(f"{self.target}: `provides` requires `expr` (a source field)")
        return self

    # convenience classifiers used by the engine
    @property
    def is_enriched(self) -> bool:
        return self.from_ is not None

    @property
    def is_source_field(self) -> bool:
        return self.provides


class MappingFile(BaseModel):
    version: int = 1
    target_entity: str
    source: str
    key: str                       # target promoted to entity_id
    event_time: str                # target promoted to event_time column
    on_missing: Literal["skip", "error", "null"] = "skip"
    mappings: List[Mapping]

    @model_validator(mode="before")
    @classmethod
    def _lift_defaults(cls, data):
        if isinstance(data, dict) and "defaults" in data:
            d = data.pop("defaults") or {}
            data.setdefault("on_missing", d.get("on_missing", "skip"))
        return data

    def plain_and_source(self) -> List[Mapping]:
        """Targets whose value comes from the current row (plain + source)."""
        return [m for m in self.mappings if not m.is_enriched]

    def enriched(self) -> List[Mapping]:
        return [m for m in self.mappings if m.is_enriched]

    def provided_fields(self) -> List[str]:
        return [m.target for m in self.mappings if m.is_source_field]


Mapping.model_rebuild()
