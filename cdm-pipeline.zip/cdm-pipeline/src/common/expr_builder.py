"""Turn a MappingFile into Spark SQL select expressions.

Produces the list of `<expr> AS <target>` strings for the plain/source targets
(the row-derived ones). Enriched targets are NOT built here -- they are applied
later by the enrichment step, because their value comes from another entity.

Supported target shapes:
  scalar : expr (+ transforms)
  struct : struct(<child> AS name, ...)          (recurses, supports dotted expand)
  map    : expr already yields a map<>            (passed through)
  array  : expr already yields an array<>         (passed through)
"""
from __future__ import annotations

from typing import Callable, Dict, List

from .mapping import Mapping, MappingFile

# Named transforms -> SQL wrappers. Extend as needed.
TRANSFORMS: Dict[str, Callable[[str], str]] = {
    "trim": lambda e: f"trim({e})",
    "lowercase": lambda e: f"lower({e})",
    "uppercase": lambda e: f"upper({e})",
    "round2": lambda e: f"round({e}, 2)",
    "round4": lambda e: f"round({e}, 4)",
}


def apply_transforms(expr: str, names: List[str]) -> str:
    for n in names:
        if n not in TRANSFORMS:
            raise ValueError(f"unknown transform: {n!r}")
        expr = TRANSFORMS[n](expr)
    return expr


def _leaf(target: str) -> str:
    return target.split(".")[-1]


def _expand_dotted(mappings: List[Mapping]) -> List[Mapping]:
    """Fold dotted targets (audit.created_by) into a single struct target."""
    out: List[Mapping] = []
    structs: Dict[str, Mapping] = {}
    for m in mappings:
        if "." not in m.target:
            out.append(m)
            continue
        parent, child = m.target.split(".", 1)
        if parent not in structs:
            structs[parent] = Mapping(target=parent, type="struct", fields=[])
            out.append(structs[parent])
        structs[parent].fields.append(
            Mapping(target=child, expr=m.expr, transforms=m.transforms)
        )
    return out


def build_expr(m: Mapping) -> str:
    """Return the SQL expression (no alias) for one row-derived mapping node."""
    if m.type == "struct":
        inner = ", ".join(f"({build_expr(f)}) AS {_leaf(f.target)}" for f in m.fields)
        return f"struct({inner})"
    # scalar / map / array: expr carries the finished SQL
    return apply_transforms(m.expr, m.transforms)


def build_row_select(mf: MappingFile) -> List[str]:
    """selectExpr list for all row-derived (plain + source) targets."""
    merged = _expand_dotted(mf.plain_and_source())
    return [f"{build_expr(m)} AS {m.target}" for m in merged]
