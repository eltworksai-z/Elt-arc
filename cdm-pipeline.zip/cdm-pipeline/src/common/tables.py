"""tables.yml models + DDL generation for Delta (L1/L2) and Postgres (L3).

The same tables.yml shape drives both:
  catalog_table / table, columns[{name,type,nullable}], partitioned_by/primary_key
Type names are given in a neutral vocabulary and mapped per backend.
"""
from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel

# neutral type -> backend type
_DELTA = {
    "string": "STRING", "long": "BIGINT", "int": "INT", "double": "DOUBLE",
    "boolean": "BOOLEAN", "timestamp": "TIMESTAMP", "variant": "VARIANT",
    "array<string>": "ARRAY<STRING>",
}
_PG = {
    "string": "text", "long": "bigint", "int": "integer", "double": "double precision",
    "boolean": "boolean", "timestamp": "timestamptz", "variant": "jsonb",
    "jsonb": "jsonb", "array<string>": "text[]",
}


def _delta_type(t: str) -> str:
    if t in _DELTA:
        return _DELTA[t]
    if t.startswith("decimal"):
        return t
    if t.startswith(("struct", "map", "array")):
        return t.upper()
    return t.upper()


def _pg_type(t: str) -> str:
    if t.startswith("decimal"):
        return t
    return _PG.get(t, "jsonb")


class Column(BaseModel):
    name: str
    type: str
    nullable: bool = True


class TableSpec(BaseModel):
    catalog_table: Optional[str] = None      # Delta 3-part name
    table: Optional[str] = None              # Postgres schema.table
    columns: List[Column]
    partitioned_by: List[str] = []
    primary_key: List[str] = []

    @property
    def name(self) -> str:
        return self.catalog_table or self.table

    def delta_ddl(self) -> str:
        cols = ",\n  ".join(
            f"{c.name} {_delta_type(c.type)}" + ("" if c.nullable else " NOT NULL")
            for c in self.columns
        )
        part = f"\nPARTITIONED BY ({', '.join(self.partitioned_by)})" if self.partitioned_by else ""
        return f"CREATE TABLE IF NOT EXISTS {self.name} (\n  {cols}\n)\nUSING DELTA{part};"

    def pg_ddl(self) -> str:
        cols = ",\n  ".join(
            f"{c.name} {_pg_type(c.type)}" + ("" if c.nullable else " NOT NULL")
            for c in self.columns
        )
        pk = f",\n  PRIMARY KEY ({', '.join(self.primary_key)})" if self.primary_key else ""
        idx = ""
        if self.primary_key:
            idx = f"\nCREATE INDEX IF NOT EXISTS {_idx(self.name)} ON {self.name} " \
                  f"({', '.join(self.primary_key)});"
        return f"CREATE TABLE IF NOT EXISTS {self.name} (\n  {cols}{pk}\n);{idx}"


def _idx(table: str) -> str:
    return "ix_" + table.replace(".", "_")
