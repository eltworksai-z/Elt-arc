"""Convert a JSON Schema file to a Spark StructType for from_json().

Supports the subset used by L1 payloads: object, string, integer, number,
boolean, and nested object/array. Extend as needed.
"""
from __future__ import annotations

import json
from pathlib import Path

from pyspark.sql.types import (
    ArrayType, BooleanType, DoubleType, LongType, StringType, StructField,
    StructType,
)

_PRIM = {
    "string": StringType(),
    "integer": LongType(),
    "number": DoubleType(),
    "boolean": BooleanType(),
}


def _to_spark(node: dict):
    t = node.get("type")
    if t == "object":
        fields = []
        for name, sub in node.get("properties", {}).items():
            fields.append(StructField(name, _to_spark(sub), True))
        return StructType(fields)
    if t == "array":
        return ArrayType(_to_spark(node.get("items", {"type": "string"})))
    return _PRIM.get(t, StringType())


def json_schema_to_struct(path: str | Path) -> StructType:
    with open(path) as f:
        schema = json.load(f)
    st = _to_spark(schema)
    assert isinstance(st, StructType), "top-level schema must be an object"
    return st
