"""L1 Bronze streaming job.

Kafka -> derive entity_type -> parse JSON per entity schema -> envelope DQ ->
entity DQ -> split valid/quarantine -> write bronze + dead_letter.

Run:
  python -m src.l1.main --conf src/l1/conf
"""
from __future__ import annotations

import argparse
from pathlib import Path

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from .config import (
    load_entity_dq, load_l1, load_registry, load_tables,
)
from .dq import apply_dq
from .schema import json_schema_to_struct
from .writer import write_bronze, write_dead_letter


def _entity_type_col(cfg, df: DataFrame) -> DataFrame:
    if cfg.parse.entity_type_from == "topic":
        # raw.ppt -> ppt
        return df.withColumn("entity_type", F.element_at(F.split(F.col("topic"), r"\."), -1))
    return df.withColumn("entity_type", F.get_json_object("value_str", "$.entity_type"))


def build_stream(spark: SparkSession, conf_dir: str) -> None:
    conf_dir = str(conf_dir)
    cfg = load_l1(conf_dir)
    registry = load_registry(conf_dir)
    tables = load_tables(conf_dir)

    # per-entity parsing schema + DQ rules, resolved once
    schemas = {e.type: json_schema_to_struct(Path(conf_dir) / e.schema)
               for e in registry.entities}
    entity_rules = {e.type: load_entity_dq(conf_dir, e.dq).data_quality.rules
                    for e in registry.entities}
    envelope_rules = cfg.data_quality.rules

    reader = spark.readStream.format(cfg.source.format)
    for k, v in cfg.source.options.items():
        reader = reader.option(k, v)
    raw = reader.load()

    def process(batch_df: DataFrame, batch_id: int) -> None:
        df = (batch_df
              .withColumn("kafka_key", F.col("key").cast("string"))
              .withColumn("value_str", F.col("value").cast("string"))
              .withColumn("kafka_topic", F.col("topic"))
              .withColumn("kafka_offset", F.col("offset").cast("long"))
              .withColumn("ingested_at", F.current_timestamp()))
        df = _entity_type_col(cfg, df)

        out_frames = []
        for etype in registry.types():
            sub = df.filter(F.col("entity_type") == etype)
            schema = schemas[etype]
            parsed = sub.withColumn(
                "data",
                F.from_json("value_str", schema, {"mode": "PERMISSIVE",
                                                  "columnNameOfCorruptRecord":
                                                  cfg.parse.corrupt_column}),
            )
            # surface parsed fields for DQ expressions + event_time
            parsed = parsed.select("*", "data.*")
            parsed = parsed.withColumn(
                cfg.parse.corrupt_column,
                F.when(F.col("data").isNull(), F.lit("unparseable")).otherwise(F.lit(None)),
            )
            parsed = parsed.withColumn("event_time",
                                       F.to_timestamp(F.col("event_time"))
                                       if "event_time" in parsed.columns
                                       else F.lit(None).cast("timestamp"))
            parsed = parsed.withColumn("raw_payload", F.col("value_str"))

            # envelope DQ then entity DQ
            parsed = apply_dq(parsed, envelope_rules)
            parsed = apply_dq(parsed, entity_rules[etype])
            out_frames.append(parsed)

        if not out_frames:
            return
        unified = out_frames[0]
        for f in out_frames[1:]:
            unified = unified.unionByName(f, allowMissingColumns=True)

        bronze_cols = ["kafka_key", "entity_type", "raw_payload", "is_valid",
                       "error_reason", "dq_failed", "kafka_topic", "kafka_offset",
                       "event_time", "ingested_at"]
        bronze = unified.select(*bronze_cols)
        write_bronze(bronze, tables["events"].name)

        # quarantine: rows that failed an ERROR rule when on_fail=quarantine
        if cfg.data_quality.on_fail == "quarantine" and "dead_letter" in tables:
            dl = (unified.filter(~F.col("is_valid"))
                  .select("kafka_key", "entity_type", "raw_payload",
                          "error_reason", "kafka_offset", "ingested_at"))
            write_dead_letter(dl, tables["dead_letter"].name)

    (raw.writeStream
        .foreachBatch(process)
        .option("checkpointLocation", cfg.checkpoint)
        .start()
        .awaitTermination())


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--conf", default="src/l1/conf")
    args = ap.parse_args()
    spark = SparkSession.builder.appName("l1-bronze").getOrCreate()
    build_stream(spark, args.conf)


if __name__ == "__main__":
    main()
