"""L1 config + registry models. Validates on load (fail fast)."""
from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Literal, Optional

from pydantic import BaseModel

from src.common.io import load_yaml
from src.common.tables import TableSpec


class DQRule(BaseModel):
    name: str
    expr: str
    severity: Literal["error", "warn"] = "error"


class DQBlock(BaseModel):
    on_fail: Literal["quarantine", "flag"] = "quarantine"
    rules: List[DQRule] = []


class Source(BaseModel):
    format: str
    options: Dict[str, str]


class Parse(BaseModel):
    value_as: str = "json"
    corrupt_column: str = "_corrupt_record"
    entity_type_from: Literal["topic", "payload"] = "topic"


class L1Config(BaseModel):
    layer: str
    source: Source
    parse: Parse
    data_quality: DQBlock
    registry: str
    tables: str
    checkpoint: str


class RegistryEntry(BaseModel):
    type: str
    schema: str
    dq: str


class Registry(BaseModel):
    version: int = 1
    entities: List[RegistryEntry]

    def types(self) -> List[str]:
        return [e.type for e in self.entities]

    def by_type(self, t: str) -> RegistryEntry:
        for e in self.entities:
            if e.type == t:
                return e
        raise KeyError(t)


class EntityDQ(BaseModel):
    entity_type: str
    data_quality: DQBlock


def load_l1(conf_dir: str | Path) -> L1Config:
    conf_dir = Path(conf_dir)
    return L1Config(**load_yaml(conf_dir / "l1.yml"))


def load_registry(conf_dir: str | Path) -> Registry:
    return Registry(**load_yaml(Path(conf_dir) / "registry.yml"))


def load_tables(conf_dir: str | Path) -> Dict[str, TableSpec]:
    raw = load_yaml(Path(conf_dir) / "tables.yml")
    dl = raw.pop("dead_letter", None)
    out = {"events": TableSpec(**raw)}
    if dl:
        out["dead_letter"] = TableSpec(**dl)
    return out


def load_entity_dq(conf_dir: str | Path, rel_path: str) -> EntityDQ:
    return EntityDQ(**load_yaml(Path(conf_dir) / rel_path))
