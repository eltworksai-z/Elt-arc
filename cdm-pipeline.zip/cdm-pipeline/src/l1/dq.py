"""Data-quality evaluation for L1.

Two tiers:
  envelope rules -- same for every message (from l1.yml)
  entity rules   -- per entity_type (from entities/<type>.yml)

Each row gets:
  dq_failed    : array<string> of failed rule names (error + warn)
  is_valid     : false if any ERROR-severity rule failed
  error_reason : first error rule name (or null)

Routing (quarantine vs flag) is decided by the caller using on_fail.
"""
from __future__ import annotations

from typing import List

from pyspark.sql import DataFrame
from pyspark.sql import functions as F

from .config import DQRule


def _fail_col(rule: DQRule):
    # returns rule name when the rule FAILS (expr is false or null), else null
    passed = F.expr(rule.expr)
    return F.when(~passed | passed.isNull(), F.lit(rule.name))


def apply_dq(df: DataFrame, rules: List[DQRule]) -> DataFrame:
    """Attach/extend dq_failed, is_valid, error_reason from `rules`."""
    if "dq_failed" not in df.columns:
        df = df.withColumn("dq_failed", F.array().cast("array<string>"))
        df = df.withColumn("error_reason", F.lit(None).cast("string"))
        df = df.withColumn("is_valid", F.lit(True))

    fail_names = [_fail_col(r) for r in rules]
    error_names = [_fail_col(r) for r in rules if r.severity == "error"]

    # append newly failed rule names (drop nulls)
    if fail_names:
        newly = F.array_compact(F.array(*fail_names))
        df = df.withColumn("dq_failed", F.array_union("dq_failed", newly))

    if error_names:
        errs = F.array_compact(F.array(*error_names))
        any_err = F.size(errs) > 0
        df = df.withColumn("is_valid", df["is_valid"] & ~any_err)
        df = df.withColumn(
            "error_reason",
            F.coalesce(df["error_reason"], F.element_at(errs, 1)),
        )
    return df
