"""L1 writers -- Delta sinks for bronze valid rows and the dead-letter table."""
from __future__ import annotations

from pyspark.sql import DataFrame


def write_bronze(batch_df: DataFrame, table: str) -> None:
    (batch_df.write.format("delta")
        .mode("append")
        .option("mergeSchema", "true")
        .saveAsTable(table))


def write_dead_letter(batch_df: DataFrame, table: str) -> None:
    if batch_df.isEmpty():
        return
    (batch_df.write.format("delta")
        .mode("append")
        .option("mergeSchema", "true")
        .saveAsTable(table))
