"""Tests for DDL generation from tables.yml (no Spark/PG needed)."""
from src.common.tables import TableSpec


def test_delta_ddl_variant_and_partition():
    spec = TableSpec(
        catalog_table="main.cdm.entities",
        columns=[
            {"name": "entity_type", "type": "string", "nullable": False},
            {"name": "entity_id", "type": "string", "nullable": False},
            {"name": "event_time", "type": "timestamp"},
            {"name": "attributes", "type": "variant"},
            {"name": "ingested_at", "type": "timestamp", "nullable": False},
        ],
        partitioned_by=["entity_type"],
    )
    ddl = spec.delta_ddl()
    assert "USING DELTA" in ddl
    assert "attributes VARIANT" in ddl
    assert "PARTITIONED BY (entity_type)" in ddl
    assert "entity_type STRING NOT NULL" in ddl


def test_postgres_ddl_jsonb_pk_index():
    spec = TableSpec(
        table="cdm.entities",
        columns=[
            {"name": "entity_type", "type": "string", "nullable": False},
            {"name": "entity_id", "type": "string", "nullable": False},
            {"name": "event_time", "type": "timestamp"},
            {"name": "attributes", "type": "jsonb"},
        ],
        primary_key=["entity_type", "entity_id"],
    )
    ddl = spec.pg_ddl()
    assert "attributes jsonb" in ddl
    assert "event_time timestamptz" in ddl
    assert "PRIMARY KEY (entity_type, entity_id)" in ddl
    assert "CREATE INDEX" in ddl
