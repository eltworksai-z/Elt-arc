"""Tests for L3 Postgres SQL generation (string builders, no DB)."""
from src.common.enrich import build_plan
from src.common.mapping import MappingFile
from src.l3.postgres import enrich_sql, scd1_sql


def test_scd1_sql_has_newest_wins_guard():
    sql = scd1_sql("cdm.entities", "stg.entities_batch",
                   ["entity_type", "entity_id"], "event_time")
    assert "ON CONFLICT (entity_type, entity_id) DO UPDATE" in sql
    assert "WHERE EXCLUDED.event_time > cdm.entities.event_time" in sql


def _customer():
    return MappingFile(
        target_entity="customer", source="s", key="customer_id", event_time="event_ts",
        mappings=[
            {"target": "customer_id", "expr": "attributes:customer_id"},
            {"target": "tier", "expr": "attributes:tier", "provides": True},
            {"target": "event_ts", "expr": "event_time"},
        ],
    )


def _ppb():
    return MappingFile(
        target_entity="ppb", source="s", key="pk", event_time="event_ts",
        mappings=[
            {"target": "pk", "expr": "attributes:pk"},
            {"target": "customer_id", "expr": "attributes:customer_id"},
            {"target": "event_ts", "expr": "event_time"},
            {"target": "customer_tier",
             "from": {"entity": "customer", "field": "tier", "on": "customer_id"}},
        ],
    )


def test_enrich_sql_updates_from_source():
    plan = build_plan({"customer": _customer(), "ppb": _ppb()})
    stmts = enrich_sql("cdm.entities", "stg.entities_batch", plan, "event_time")
    assert len(stmts) == 1
    s = stmts[0]
    assert "UPDATE cdm.entities t" in s
    assert "jsonb_build_object('customer_tier'" in s
    assert "s.attributes->'tier'" in s
    # scoped to targets and matched on the join attribute
    assert "t.entity_type IN ('ppb')" in s
    assert "(t.attributes->>'customer_id') = s.entity_id" in s
    # scoped to changed source keys this batch
    assert "FROM stg.entities_batch" in s
