"""L3 config + registry models (Postgres sink)."""
from __future__ import annotations

from pathlib import Path
from typing import List, Literal, Optional

from pydantic import BaseModel

from src.common.io import load_yaml


class Source(BaseModel):
    format: str
    catalog_table: str
    read_change_feed: bool = False
    filter: Optional[str] = None


class Watermark(BaseModel):
    column: str
    delay: str


class SCD(BaseModel):
    mode: Literal["scd1"] = "scd1"
    table: str
    business_key: List[str]
    order_by: str


class Postgres(BaseModel):
    url: str
    user: str
    password: str
    table: str
    staging_table: str


class Sink(BaseModel):
    postgres: Postgres


class L3Config(BaseModel):
    layer: str
    source: Source
    watermark: Optional[Watermark] = None
    scd: SCD
    sink: Sink
    registry: str
    tables: str
    entities_dir: str
    checkpoint: str


class RegistryEntry(BaseModel):
    type: str
    role: Literal["source", "target", "plain"] = "plain"
    mapping: str


class Registry(BaseModel):
    version: int = 1
    entities: List[RegistryEntry]


def load_l3(conf_dir: str | Path) -> L3Config:
    return L3Config(**load_yaml(Path(conf_dir) / "l3.yml"))


def load_registry(conf_dir: str | Path) -> Registry:
    return Registry(**load_yaml(Path(conf_dir) / "registry.yml"))
