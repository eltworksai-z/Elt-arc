"""Postgres SQL builders for L3.

Same logic as L2's Delta MERGEs, expressed in Postgres:
  SCD1 upsert  -> INSERT ... ON CONFLICT DO UPDATE (newest-wins guard)
  enrichment   -> UPDATE ... FROM (patch target jsonb from source jsonb)

attributes is JSONB; a single key is patched with the || jsonb_build_object
idiom so the rest of the object survives.
"""
from __future__ import annotations

from typing import List

from src.common.enrich import EnrichPlan


def scd1_sql(target: str, staging: str, business_key: List[str],
             order_by: str) -> str:
    key_cols = ", ".join(business_key)
    conflict = ", ".join(business_key)
    return f"""
        INSERT INTO {target} (entity_type, entity_id, event_time, attributes)
        SELECT entity_type, entity_id, event_time, attributes FROM {staging}
        ON CONFLICT ({conflict}) DO UPDATE
        SET attributes = EXCLUDED.attributes,
            event_time = EXCLUDED.event_time
        WHERE EXCLUDED.{order_by} > {target}.{order_by};
    """.strip()


def enrich_sql(target: str, staging: str, plan: EnrichPlan,
               order_by: str) -> List[str]:
    """One UPDATE per (source_entity, join key) group.

    Scoped to keys whose source changed in this batch (present in staging),
    using the newest source row per key.
    """
    statements: List[str] = []
    for (source_entity, on), edges in plan.grouped_lookups().items():
        target_types = sorted({e.target_entity for e in edges})
        in_list = ", ".join(f"'{t}'" for t in target_types)

        # build the jsonb patch: chain || jsonb_build_object(k, src->k)
        patch = "t.attributes"
        for e in edges:
            patch = (f"{patch} || jsonb_build_object("
                     f"'{e.target_field}', s.attributes->'{e.source_field}')")

        # newest source per join key (entity_id of the source == join key)
        # join target.<on-attr> to source.entity_id
        statements.append(f"""
            UPDATE {target} t
            SET attributes = {patch}
            FROM (
                SELECT DISTINCT ON (entity_id) entity_id, attributes
                FROM {target}
                WHERE entity_type = '{source_entity}'
                  AND entity_id IN (
                      SELECT entity_id FROM {staging}
                      WHERE entity_type = '{source_entity}')
                ORDER BY entity_id, {order_by} DESC
            ) s
            WHERE t.entity_type IN ({in_list})
              AND (t.attributes->>'{on}') = s.entity_id;
        """.strip())
    return statements
