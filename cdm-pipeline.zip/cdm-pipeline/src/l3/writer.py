"""L3 Postgres writer.

foreachBatch flow, all in ONE Postgres transaction so a batch is atomic:
  1. write this micro-batch to a staging table (bulk JDBC overwrite)
  2. SCD1 upsert staging -> main (ON CONFLICT)
  3. enrichment UPDATE ... FROM (patch targets from sources)

Requires psycopg2 on the driver. JDBC is used for the bulk staging write;
psycopg2 runs the set-based upsert + enrichment.
"""
from __future__ import annotations

from typing import List

from pyspark.sql import DataFrame

from .config import Postgres


def _jdbc_overwrite(df: DataFrame, pg: Postgres, table: str) -> None:
    (df.write.format("jdbc")
        .option("url", pg.url)
        .option("dbtable", table)
        .option("user", pg.user)
        .option("password", pg.password)
        .option("truncate", "true")
        .mode("overwrite")
        .save())


def write_batch(batch_df: DataFrame, pg: Postgres, scd1_stmt: str,
                enrich_stmts: List[str]) -> None:
    import psycopg2  # driver-side import

    staging = pg.staging_table
    # 1. bulk-land the batch into staging
    _jdbc_overwrite(
        batch_df.select("entity_type", "entity_id", "event_time", "attributes"),
        pg, staging,
    )

    # 2 + 3. upsert then enrich, atomically
    dsn = _dsn_from_jdbc(pg)
    conn = psycopg2.connect(dsn)
    try:
        with conn:
            with conn.cursor() as cur:
                cur.execute(scd1_stmt)
                for stmt in enrich_stmts:
                    cur.execute(stmt)
    finally:
        conn.close()


def _dsn_from_jdbc(pg: Postgres) -> str:
    # jdbc:postgresql://host:port/db -> host=... port=... dbname=...
    tail = pg.url.replace("jdbc:postgresql://", "")
    hostport, db = tail.split("/", 1)
    host, port = (hostport.split(":") + ["5432"])[:2]
    db = db.split("?")[0]
    return f"host={host} port={port} dbname={db} user={pg.user} password={pg.password}"
