"""L3 CDM (Postgres) streaming job.

Reads L2 cdm.entities (Delta stream), applies NEW enrichments, writes to
Postgres cdm.entities via staging + ON CONFLICT + UPDATE...FROM.

Run:
  python -m src.l3.main --conf src/l3/conf
"""
from __future__ import annotations

import argparse
from pathlib import Path
from typing import Dict, List

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from src.common.enrich import build_plan
from src.common.expr_builder import build_row_select
from src.common.io import load_mapping_files
from src.common.mapping import MappingFile

from .config import load_l3, load_registry
from .postgres import enrich_sql, scd1_sql
from .writer import write_batch


def _map_entity(sub: DataFrame, mf: MappingFile) -> DataFrame:
    mapped = sub.selectExpr(*build_row_select(mf))
    attr_targets = [m.target for m in mf.plain_and_source()]
    struct_cols = ", ".join(f"'{t}', {t}" for t in attr_targets)
    mapped = mapped.withColumn("attributes",
                               F.expr(f"to_json(named_struct({struct_cols}))"))
    return (mapped
            .withColumn("entity_type", F.lit(mf.target_entity))
            .withColumn("entity_id", F.col(mf.key).cast("string"))
            .withColumn("event_time", F.col(mf.event_time))
            .select("entity_type", "entity_id", "event_time", "attributes"))


def build_stream(spark: SparkSession, conf_dir: str) -> None:
    conf_dir = str(conf_dir)
    cfg = load_l3(conf_dir)
    load_registry(conf_dir)
    mapping_files: Dict[str, MappingFile] = load_mapping_files(
        Path(conf_dir) / "entities")
    plan = build_plan(mapping_files)

    pg = cfg.sink.postgres
    scd1_stmt = scd1_sql(pg.table, pg.staging_table,
                         cfg.scd.business_key, cfg.scd.order_by)
    enrich_stmts: List[str] = enrich_sql(pg.table, pg.staging_table,
                                         plan, cfg.scd.order_by)

    reader = (spark.readStream.format(cfg.source.format)
              .option("readChangeFeed", str(cfg.source.read_change_feed).lower()))
    src = reader.table(cfg.source.catalog_table)
    if cfg.source.filter:
        src = src.filter(F.expr(cfg.source.filter))
    if cfg.watermark:
        src = src.withWatermark(cfg.watermark.column, cfg.watermark.delay)

    def run(batch_df: DataFrame, batch_id: int) -> None:
        frames: List[DataFrame] = []
        for etype, mf in mapping_files.items():
            sub = batch_df.filter(F.col("entity_type") == etype)
            if sub.isEmpty():
                continue
            frames.append(_map_entity(sub, mf))
        if not frames:
            return
        cdm = frames[0]
        for f in frames[1:]:
            cdm = cdm.unionByName(f)
        write_batch(cdm, pg, scd1_stmt, enrich_stmts)

    (src.writeStream
        .foreachBatch(run)
        .option("checkpointLocation", cfg.checkpoint)
        .start()
        .awaitTermination())


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--conf", default="src/l3/conf")
    args = ap.parse_args()
    spark = SparkSession.builder.appName("l3-cdm-postgres").getOrCreate()
    build_stream(spark, args.conf)


if __name__ == "__main__":
    main()
