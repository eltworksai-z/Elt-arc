"""Generate CREATE TABLE DDL from any layer's tables.yml.

Usage:
  python ddl/generate_ddl.py src/l2/conf/tables.yml --dialect delta
  python ddl/generate_ddl.py src/l3/conf/tables.yml --dialect postgres

Handles the extra blocks: L1 dead_letter, L3 staging.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.common.io import load_yaml
from src.common.tables import TableSpec


def _specs(raw: dict):
    specs = []
    dead_letter = raw.pop("dead_letter", None)
    staging = raw.pop("staging", None)
    specs.append(TableSpec(**raw))
    if dead_letter:
        specs.append(TableSpec(**dead_letter))
    if staging:
        specs.append(TableSpec(**staging))
    return specs


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("tables_yml")
    ap.add_argument("--dialect", choices=["delta", "postgres"], required=True)
    args = ap.parse_args()

    raw = load_yaml(args.tables_yml)
    for spec in _specs(raw):
        print(spec.delta_ddl() if args.dialect == "delta" else spec.pg_ddl())
        print()


if __name__ == "__main__":
    main()
