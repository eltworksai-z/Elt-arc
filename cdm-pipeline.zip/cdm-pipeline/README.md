# CDM Pipeline — Spark Structured Streaming (L1 → L2 → L3)

A config-driven, three-layer streaming pipeline that ingests raw events from
Kafka, validates them, and builds a **Common Data Model (CDM)** where many
entity types share one table (`attributes` held as a semi-structured column),
with **cross-entity enrichment** and **SCD1** upserts at each CDM layer.

Everything that changes per project lives in **YAML** (`conf/`). The Python is a
generic engine that reads those configs. There is **no global config** — each
layer owns its `conf/`. Only the pure-logic engine (`src/common/`) is shared.

---

## Layers

```
Kafka ─► L1 Bronze ─► L2 CDM (Delta) ─► L3 CDM (Postgres)
         validate      map + enrich       new enrich + serve
         + quarantine   SCD1 (VARIANT)     SCD1 (JSONB)
```

| Layer | Reads | Writes | Job |
|-------|-------|--------|-----|
| **L1** | Kafka topics | `main.bronze.events` + `main.bronze.dead_letter` (Delta) | validate raw JSON, envelope DQ + entity DQ, quarantine bad rows |
| **L2** | `main.bronze.events` (valid) | `main.cdm.entities` (Delta, `attributes` VARIANT) | map to CDM, enrich across entities, SCD1 |
| **L3** | `main.cdm.entities` | Postgres `cdm.entities` (`attributes` JSONB) | **new** enrichments L2 didn't do, SCD1 into Postgres |

L2 and L3 are **both CDM layers** and share the same mapping grammar and engine.
They differ only in executor: Delta `MERGE` at L2, Postgres `ON CONFLICT` +
`UPDATE...FROM` at L3.

---

## The mapping grammar

Each entity type is described by one file in `conf/entities/<type>.yml`. Every
entry in `mappings:` is a **target field** with one of three origins:

| Entry has | Kind | Value from |
|-----------|------|-----------|
| `expr` | plain | the current row |
| `expr` + `provides: true` | source | the current row, *and* exposed for enrichment |
| `from: {entity, field, on}` | enriched | pulled from another entity, matched on a key |

```yaml
version: 1
target_entity: ppb
source: main.bronze.events
key: pk                 # -> promoted to entity_id
event_time: event_ts    # -> promoted to event_time column
mappings:
  - {target: pk,       expr: "pk", required: true}
  - {target: qty,      expr: "CAST(qty AS INT)"}
  - {target: event_ts, expr: "to_timestamp(event_time)", required: true}

  # enriched: pull complex_weight from ppt, matched on pk, then round
  - target: complex_weight
    from: {entity: ppt, field: complex_weight, "on": pk}
    transforms: [round2]
```

The source entity must expose the field:

```yaml
# ppt.yml
mappings:
  - {target: complex_weight, expr: "CAST(weight AS DOUBLE)", provides: true}
```

**Multiple enrichments, same source + key** collapse into one join, e.g. pulling
both `complex_weight` and `grade` from `ppt` on `pk` is a single lookup.

> Note: quote `"on"` in flow-style `from:` blocks — bare `on` is parsed as a
> boolean by YAML. (The loader also normalizes this defensively.)

---

## The enrichment algorithm (L2 / L3)

Per micro-batch, in fixed order:

1. **Map** each incoming row to CDM shape (`entity_type, entity_id, event_time,
   attributes`).
2. **Dedupe** newest per `(entity_type, entity_id)` — latest `event_time` wins.
3. **SCD1 upsert** all entities into the CDM table (newest-wins guard:
   `s.event_time > t.event_time`). This commits sources *before* enrichment
   reads them, which is why same-batch source+target works.
4. **Enrich** targets from the committed sources, scoped to keys whose source
   changed this batch. One statement per `(source, join-key)` group.

Because step 4 reads **state from the table**, arrival order doesn't matter:

| Case | Handled by |
|------|-----------|
| source + target in same batch | step 3 commits source, step 4 reads it |
| source earlier, target now | step 4 reads committed source |
| target earlier, source now | step 4 re-patches the existing target row |
| source updates again | step 3 newest-wins + step 4 re-patch |
| duplicate rows in a batch | step 2 dedupe |

`attributes` is patched **one key at a time** (`object_insert` on Delta VARIANT,
`|| jsonb_build_object(...)` on Postgres JSONB) so the rest of the object
survives.

---

## Repo layout

```
src/
  common/            # shared engine (pure logic, unit-tested, no Spark)
    mapping.py         # mapping models + validation
    expr_builder.py    # mapping -> selectExpr
    enrich.py          # from/provides -> enrichment plan (+ validation)
    tables.py          # tables.yml -> Delta / Postgres DDL
    io.py              # yaml + env loading
  l1/                # bronze: kafka -> validate -> quarantine
    conf/  (l1.yml, tables.yml, registry.yml, schemas/*.json, entities/*.yml)
    config.py schema.py dq.py writer.py main.py
  l2/                # CDM (Delta): map + enrich + SCD1
    conf/  (l2.yml, tables.yml, registry.yml, entities/*.yml)
    config.py cdm.py main.py
  l3/                # CDM (Postgres): new enrich + SCD1
    conf/  (l3.yml, tables.yml, registry.yml, entities/*.yml)
    config.py postgres.py writer.py main.py
ddl/generate_ddl.py  # tables.yml -> CREATE TABLE (delta|postgres)
deploy/              # create_tables.py + per-layer job specs
```

### The config files (same shape every layer)

| File | Owns | Read |
|------|------|------|
| `conf/<layer>.yml` | source, sink, SCD, watermark, checkpoint (+ L1 envelope DQ) | per batch |
| `conf/tables.yml` | physical columns → DDL | deploy |
| `conf/registry.yml` | allowed entity types + roles + file paths | startup |
| `conf/entities/*.yml` | L1: schema + DQ · L2/L3: mapping | per batch |

---

## Running

### 1. Environment variables

```
KAFKA_BROKERS=broker:9092
CHECKPOINT_ROOT=/chk               # or a UC volume / cloud path
PG_URL=jdbc:postgresql://pg:5432/serving
PG_USER=...
PG_PASS=...
REGISTRY_TYPES='ppt','ppb','peb','invoice'   # for L1 envelope type_known rule
```

### 2. Create tables (once)

```bash
python ddl/generate_ddl.py src/l1/conf/tables.yml --dialect delta
python ddl/generate_ddl.py src/l2/conf/tables.yml --dialect delta
python ddl/generate_ddl.py src/l3/conf/tables.yml --dialect postgres
# or: python deploy/create_tables.py   (prints all DDL)
```

### 3. Start the streams

```bash
python -m src.l1.main --conf src/l1/conf
python -m src.l2.main --conf src/l2/conf
python -m src.l3.main --conf src/l3/conf
```

On Databricks, submit each `src/<layer>/main.py` as a job (see `deploy/jobs/`).

### 4. Tests

```bash
pip install -r requirements.txt
python -m pytest src/ -q
```

The unit tests cover the shared engine (mapping validation, expr building,
enrichment plan derivation, DDL, Postgres SQL) and run without Spark.

---

## Adding a new entity type

1. Add a JSON schema in `l1/conf/schemas/` and a DQ file in `l1/conf/entities/`.
2. Add a mapping file in `l2/conf/entities/` (and `l3/` if it goes that far).
3. Register it in each layer's `registry.yml`.

No engine code changes. Enrichment wiring is derived from the mapping files.

---

## Scaling notes (many entity types / enrichments)

- The algorithm stays the same regardless of entity count; enrichment is
  **set-based** (one statement per source+key group), not per-type.
- **Partition/cluster** the CDM table by `entity_type` so enrichment MERGEs prune
  instead of scanning all types.
- The enrichment predicate is **scoped by target type** (`entity_type IN (...)`) —
  load-bearing when PK values can collide across types.
- If reading sources back from the CDM table becomes a bottleneck at high entity
  counts, introduce a narrow state table (pk + provided fields) and point the
  enrichment lookup at it. Not needed by default.
- State/table growth: apply a **retention window** on sources if targets can
  arrive arbitrarily late; otherwise the table grows unbounded.

---

## Correctness guarantees

- **Idempotent under batch replay** — all writes are keyed upserts with
  newest-wins guards, so `foreachBatch` re-execution is safe.
- **Order-independent** — correctness comes from `event_time` comparison, not
  arrival order. Provide a monotonic tiebreaker (offset/version) if timestamps
  can tie.
- **Atomic per batch at L3** — staging load, upsert, and enrichment run in one
  Postgres transaction.
