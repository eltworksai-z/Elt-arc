"""Reusable data quality check expressions returning a boolean pass column."""
from __future__ import annotations

from pyspark.sql import Column
from pyspark.sql import functions as F


def _target(root: str, path: str) -> Column:
    """Return a column reference for a dotted field path preserving special characters."""
    parts = path.split(".", 1)
    if len(parts) == 1:
        return F.col(parts[0])
    return F.col(parts[0]).getField(parts[1])


def not_empty(root: str, path: str, args: dict) -> Column:
    """Pass when the target is non-null and not blank after trimming."""
    col = _target(root, path)
    return col.isNotNull() & (F.trim(col.cast("string")) != F.lit(""))


def matches(root: str, path: str, args: dict) -> Column:
    """Pass when the target matches the configured regular expression."""
    col = _target(root, path).cast("string")
    return col.rlike(args["pattern"])


def in_set(root: str, path: str, args: dict) -> Column:
    """Pass when the target value is a member of the configured allowed set."""
    col = _target(root, path).cast("string")
    return col.isin(args["values"])


def is_timestamp(root: str, path: str, args: dict) -> Column:
    """Pass when the target parses as a timestamp using any configured format."""
    col = _target(root, path).cast("string")
    parsed = F.coalesce(*[F.to_timestamp(col, fmt) for fmt in args["formats"]])
    return parsed.isNotNull()


def not_future(root: str, path: str, args: dict) -> Column:
    """Pass when the parsed target timestamp is not later than the current time."""
    col = _target(root, path).cast("string")
    parsed = F.coalesce(*[F.to_timestamp(col, fmt) for fmt in args["formats"]])
    return parsed.isNull() | (parsed <= F.current_timestamp())


REGISTRY = {
    "not_empty": not_empty,
    "matches": matches,
    "in_set": in_set,
    "is_timestamp": is_timestamp,
    "not_future": not_future,
}
