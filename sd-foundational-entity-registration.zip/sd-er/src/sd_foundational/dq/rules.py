"""Application of configured data quality rules to a parsed event DataFrame."""
from __future__ import annotations

from pyspark.sql import DataFrame
from pyspark.sql import functions as F

from .checks import REGISTRY

DQ_ERRORS = "_dq_errors"
DQ_WARNINGS = "_dq_warnings"
DQ_FAILED = "_dq_failed"


def apply_rules(df: DataFrame, rules: list) -> DataFrame:
    """Attach data quality error, warning, and failure columns from configured rules."""
    error_msgs, warning_msgs = [], []
    for rule in rules:
        root = rule.field.split(".", 1)[0]
        check = REGISTRY[rule.check]
        passed = check(root, rule.field, rule.args)
        message = F.lit(f"{rule.field}:{rule.check}")
        entry = F.when(~F.coalesce(passed, F.lit(False)), message)
        if rule.severity == "error":
            error_msgs.append(entry)
        else:
            warning_msgs.append(entry)

    empty = F.array().cast("array<string>")
    errors = F.array_compact(F.array(*error_msgs)) if error_msgs else empty
    warnings = F.array_compact(F.array(*warning_msgs)) if warning_msgs else empty
    return (
        df.withColumn(DQ_ERRORS, errors)
        .withColumn(DQ_WARNINGS, warnings)
        .withColumn(DQ_FAILED, F.size(F.col(DQ_ERRORS)) > 0)
    )
