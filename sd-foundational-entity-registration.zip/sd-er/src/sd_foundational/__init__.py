"""Foundational entity registration pipeline for the L1 RAW and Silver medallion flow."""

__version__ = "0.1.0"
