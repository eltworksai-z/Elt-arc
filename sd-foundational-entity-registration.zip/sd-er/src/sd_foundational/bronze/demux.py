"""Stage 3: fan raw_validated out into one typed RAW table per entity type."""
from __future__ import annotations

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.streaming import StreamingQuery

from ..common import naming
from ..common.config import EnvConfig, load_entities
from ..common.schemas import data_struct
from ..common.spark import get_spark

_CARRIED = [
    "kafka_key", "kafka_ts", "ingest_ts", "entity_id", "event_id",
    "action", "event_ts", "schema_version",
]


def _foreach_batch(env: EnvConfig):
    """Return a foreachBatch handler that writes each entity subset to its typed table."""
    entities = load_entities()

    def handle(batch: DataFrame, _batch_id: int) -> None:
        for cfg in entities:
            sub = batch.filter(F.col("entity_type") == cfg.entity_type)
            if sub.isEmpty():
                continue
            struct = data_struct(cfg.table_name, cfg.schema_version)
            typed = sub.withColumn("data", F.from_json("data_json", struct)).select(
                *_CARRIED, "data.*"
            )
            typed.write.format("delta").mode("append").option(
                "mergeSchema", "true"
            ).saveAsTable(naming.raw_typed_table(env, cfg.table_name))

    return handle


def run(env: EnvConfig) -> StreamingQuery:
    """Stream raw_validated and demultiplex records into the typed RAW tables."""
    spark = get_spark()
    source = spark.readStream.format("delta").table(naming.table(env, naming.RAW_VALIDATED))
    return (
        source.writeStream.foreachBatch(_foreach_batch(env))
        .option("checkpointLocation", naming.checkpoint(env, "demux"))
        .trigger(processingTime=env.streaming.trigger_processing_time)
        .start()
    )
