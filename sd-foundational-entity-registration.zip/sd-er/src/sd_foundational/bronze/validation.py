"""Stage 2: schema-validate and DQ-check raw_landing into raw_validated and raw_rejected."""
from __future__ import annotations

from functools import reduce

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.streaming import StreamingQuery

from ..common import naming
from ..common.config import EnvConfig, entity_by_type
from ..common.schemas import data_struct, make_schema_validator
from ..common.spark import get_spark
from ..contracts import envelope
from ..dq.rules import DQ_ERRORS, DQ_FAILED, DQ_WARNINGS, apply_rules

_VALIDATED_COLS = [
    "kafka_key", "kafka_topic", "kafka_partition", "kafka_offset", "kafka_ts",
    "ingest_ts", "entity_type", "schema_version",
    "entity_id", "event_id", "action", "event_ts", "source",
    "originating_system_id", "user", "data_json", DQ_WARNINGS,
]


def _with_envelope(df: DataFrame) -> DataFrame:
    """Extract the common envelope fields and the data section as a JSON string."""
    return (
        df.withColumn("entity_id", envelope.envelope_field("payload_raw", envelope.ENTITY_ID))
        .withColumn("event_id", envelope.envelope_field("payload_raw", envelope.EVENT_ID))
        .withColumn("action", envelope.envelope_field("payload_raw", envelope.ACTION))
        .withColumn("event_ts", envelope.sequence_ts(
            envelope.envelope_field("payload_raw", envelope.TIMESTAMP)))
        .withColumn("source", envelope.envelope_field("payload_raw", envelope.SOURCE))
        .withColumn("originating_system_id",
                    envelope.envelope_field("payload_raw", envelope.ORIGINATING_SYSTEM_ID))
        .withColumn("user", envelope.envelope_field("payload_raw", envelope.USER))
        .withColumn("data_json", F.get_json_object(F.col("payload_raw"), "$.data"))
    )


def _process_entity(sub: DataFrame, cfg) -> tuple:
    """Return the validated and rejected frames for a single entity type subset."""
    validator = make_schema_validator(cfg.table_name, cfg.schema_version)
    checked = sub.withColumn("_schema_error", validator(F.col("payload_raw")))

    schema_ok = checked.filter(F.col("_schema_error") == F.lit(""))
    schema_bad = (
        checked.filter(F.col("_schema_error") != F.lit(""))
        .withColumn("reject_stage", F.lit("schema"))
        .withColumn("reject_reason", F.array(F.col("_schema_error")))
    )

    struct = data_struct(cfg.table_name, cfg.schema_version)
    parsed = schema_ok.withColumn(
        "event", F.from_json(F.col("payload_raw"), _event_schema())
    ).withColumn("data", F.from_json(F.col("data_json"), struct))
    scored = apply_rules(parsed, cfg.dq_rules)

    validated = scored.filter(~F.col(DQ_FAILED)).select(*_VALIDATED_COLS)
    dq_bad = (
        scored.filter(F.col(DQ_FAILED))
        .withColumn("reject_stage", F.lit("dq"))
        .withColumn("reject_reason", F.col(DQ_ERRORS))
    )
    rejected_cols = _VALIDATED_COLS[:-1] + ["payload_raw", "reject_stage", "reject_reason"]
    rejected = schema_bad.select(*_reject_select(schema_bad, rejected_cols)).unionByName(
        dq_bad.select(*_reject_select(dq_bad, rejected_cols)), allowMissingColumns=True
    )
    return validated, rejected


def _reject_select(df: DataFrame, cols: list) -> list:
    """Return existing columns from the requested reject projection, filling absentees."""
    present = set(df.columns)
    return [c if c in present else F.lit(None).alias(c) for c in cols]


def _event_schema():
    """Return the Spark struct for the shared event envelope."""
    from pyspark.sql.types import StringType, StructField, StructType

    names = ["action", "entityId", "entityType", "originatingSystemId", "user",
             "timeStamp", "eventId", "source", "schemaVersionId"]
    return StructType([StructField(n, StringType(), True) for n in names])


def _foreach_batch(env: EnvConfig):
    """Return a foreachBatch handler that validates and splits each micro-batch."""
    registry = entity_by_type()

    def handle(batch: DataFrame, _batch_id: int) -> None:
        prepared = _with_envelope(batch)
        prepared.persist()
        try:
            present = [r[0] for r in prepared.select("entity_type").distinct().collect()]
            validated, rejected = [], []
            for entity_type in present:
                if entity_type not in registry:
                    continue
                sub = prepared.filter(F.col("entity_type") == entity_type)
                good, bad = _process_entity(sub, registry[entity_type])
                validated.append(good)
                rejected.append(bad)

            unknown = prepared.filter(~F.col("entity_type").isin(list(registry.keys())))

            if validated:
                reduce(DataFrame.unionByName, validated).write.format("delta").mode(
                    "append"
                ).saveAsTable(naming.table(env, naming.RAW_VALIDATED))
            if rejected:
                combined = reduce(DataFrame.unionByName, rejected)
                combined.write.format("delta").mode("append").saveAsTable(
                    naming.table(env, naming.RAW_REJECTED)
                )
            _write_unknown(env, unknown)
        finally:
            prepared.unpersist()

    return handle


def _write_unknown(env: EnvConfig, unknown: DataFrame) -> None:
    """Route records with an unrecognised entity_type to the reject table."""
    if unknown.isEmpty():
        return
    (
        unknown.withColumn("reject_stage", F.lit("routing"))
        .withColumn("reject_reason", F.array(F.lit("unknown_entity_type")))
        .write.format("delta").mode("append")
        .option("mergeSchema", "true")
        .saveAsTable(naming.table(env, naming.RAW_REJECTED))
    )


def run(env: EnvConfig) -> StreamingQuery:
    """Stream raw_landing through schema and DQ validation into validated and rejected tables."""
    spark = get_spark()
    source = spark.readStream.format("delta").table(naming.table(env, naming.RAW_LANDING))
    return (
        source.writeStream.foreachBatch(_foreach_batch(env))
        .option("checkpointLocation", naming.checkpoint(env, naming.RAW_VALIDATED))
        .trigger(processingTime=env.streaming.trigger_processing_time)
        .start()
    )
