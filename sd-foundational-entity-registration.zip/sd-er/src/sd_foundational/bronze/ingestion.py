"""Stage 1: stream the generic Kafka topic into the immutable raw_landing table."""
from __future__ import annotations

from pyspark.sql import functions as F
from pyspark.sql.streaming import StreamingQuery

from ..common import naming
from ..common.config import EnvConfig
from ..common.spark import get_secret, get_spark
from ..contracts import envelope


def _kafka_options(env: EnvConfig) -> dict:
    """Return the Kafka source options assembled from environment config and secrets."""
    k = env.kafka
    options = {
        "kafka.bootstrap.servers": get_secret(k.bootstrap_secret_scope, k.bootstrap_secret_key),
        "subscribe": k.topic,
        "startingOffsets": k.starting_offsets,
        "maxOffsetsPerTrigger": str(k.max_offsets_per_trigger),
        "failOnDataLoss": "false",
    }
    if k.security_protocol:
        options["kafka.security.protocol"] = k.security_protocol
    options.update(k.extra_options)
    return options


def run(env: EnvConfig) -> StreamingQuery:
    """Append raw Kafka records and the entity_type discriminator to raw_landing."""
    spark = get_spark()
    source = (
        spark.readStream.format("kafka")
        .options(**_kafka_options(env))
        .load()
        .select(
            F.col("key").cast("string").alias("kafka_key"),
            F.col("value").cast("string").alias("payload_raw"),
            F.col("topic").alias("kafka_topic"),
            F.col("partition").alias("kafka_partition"),
            F.col("offset").alias("kafka_offset"),
            F.col("timestamp").alias("kafka_ts"),
            envelope.envelope_field("payload_raw", envelope.ENTITY_TYPE).alias("entity_type"),
            envelope.envelope_field("payload_raw", envelope.SCHEMA_VERSION).alias("schema_version"),
            F.current_timestamp().alias("ingest_ts"),
        )
    )
    return (
        source.writeStream.format("delta")
        .option("checkpointLocation", naming.checkpoint(env, naming.RAW_LANDING))
        .outputMode("append")
        .trigger(processingTime=env.streaming.trigger_processing_time)
        .toTable(naming.table(env, naming.RAW_LANDING))
    )
