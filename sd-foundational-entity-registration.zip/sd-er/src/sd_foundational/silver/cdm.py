"""Common data model mapping from validated events to the canonical current shape."""
from __future__ import annotations

from pyspark.sql import DataFrame
from pyspark.sql import functions as F

from ..common.config import EntityConfig
from ..common.schemas import data_struct
from ..contracts import envelope

CANONICAL_KEYS = ["entity_type", "business_key"]
AUDIT_COLS = ["op", "seq_ts", "event_id", "source", "originating_system_id",
              "action", "ingest_ts", "attributes"]


def to_canonical(df: DataFrame, cfg: EntityConfig) -> DataFrame:
    """Map a single entity's validated events to the unified canonical columns."""
    typed = df.withColumn(
        "data", F.from_json("data_json", data_struct(cfg.table_name, cfg.schema_version))
    )
    mapped = typed
    for source_field, canonical_col in cfg.canonical_mapping.items():
        mapped = mapped.withColumn(canonical_col, F.col("data").getField(source_field))

    is_delete = F.col("action").isin(list(envelope.DELETE_ACTIONS))
    canonical_cols = list(cfg.canonical_mapping.values())
    return (
        mapped.withColumn("entity_type", F.lit(cfg.entity_type))
        .withColumn("business_key", F.col("entity_id"))
        .withColumn("op", F.when(is_delete, F.lit("D")).otherwise(F.lit("U")))
        .withColumn("seq_ts", F.col("event_ts"))
        .withColumn("attributes", F.parse_json(F.col("data_json")))
        .select(*CANONICAL_KEYS, *canonical_cols, *AUDIT_COLS)
    )
