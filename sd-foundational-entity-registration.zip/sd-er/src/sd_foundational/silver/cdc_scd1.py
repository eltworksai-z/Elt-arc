"""Stage 4: merge validated events into the canonical SCD1 cdc_current table."""
from __future__ import annotations

from functools import reduce

from delta.tables import DeltaTable
from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.streaming import StreamingQuery
from pyspark.sql.window import Window

from ..common import naming
from ..common.config import EnvConfig, entity_by_type
from ..common.spark import get_spark
from .cdm import to_canonical

_MERGE_KEY = "t.entity_type = s.entity_type AND t.business_key = s.business_key"


def _latest_per_key(df: DataFrame) -> DataFrame:
    """Reduce a batch to the highest-sequence row per canonical key."""
    window = Window.partitionBy("entity_type", "business_key").orderBy(F.col("seq_ts").desc())
    return df.withColumn("_rn", F.row_number().over(window)).filter(F.col("_rn") == 1).drop("_rn")


def _merge(env: EnvConfig, latest: DataFrame) -> None:
    """Apply an SCD1 upsert-and-delete merge guarded by the sequence timestamp."""
    target = DeltaTable.forName(get_spark(), naming.table(env, naming.CDC_CURRENT))
    (
        target.alias("t")
        .merge(latest.alias("s"), _MERGE_KEY)
        .whenMatchedDelete(condition="s.op = 'D' AND s.seq_ts > t.seq_ts")
        .whenMatchedUpdateAll(condition="s.op = 'U' AND s.seq_ts > t.seq_ts")
        .whenNotMatchedInsertAll(condition="s.op = 'U'")
        .execute()
    )


def _foreach_batch(env: EnvConfig):
    """Return a foreachBatch handler that canonicalises, dedups, and merges a batch."""
    registry = entity_by_type()

    def handle(batch: DataFrame, _batch_id: int) -> None:
        frames = []
        for entity_type, cfg in registry.items():
            sub = batch.filter(F.col("entity_type") == entity_type)
            if sub.isEmpty():
                continue
            frames.append(to_canonical(sub, cfg))
        if not frames:
            return
        canonical = reduce(DataFrame.unionByName, frames)
        _merge(env, _latest_per_key(canonical))

    return handle


def run(env: EnvConfig) -> StreamingQuery:
    """Stream raw_validated into the canonical SCD1 current table via guarded merges."""
    spark = get_spark()
    source = spark.readStream.format("delta").table(naming.table(env, naming.RAW_VALIDATED))
    return (
        source.writeStream.foreachBatch(_foreach_batch(env))
        .option("checkpointLocation", naming.checkpoint(env, "silver_cdc"))
        .trigger(processingTime=env.streaming.trigger_processing_time)
        .start()
    )
