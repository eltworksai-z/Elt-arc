"""Shared argument parsing for stage entrypoints."""
from __future__ import annotations

import argparse

from ..common.config import EnvConfig, load_env


def parse_env() -> EnvConfig:
    """Parse the --env argument and return the resolved environment configuration."""
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", required=True)
    args, _ = parser.parse_known_args()
    return load_env(args.env)
