"""Entrypoint that ensures target tables exist, launches the silver_cdc stream, and blocks."""
from __future__ import annotations

from ..common.bootstrap import ensure_objects
from ..common.logging import get_logger
from ..silver.cdc_scd1 import run
from ._args import parse_env

_log = get_logger(__name__)


def main() -> None:
    """Ensure objects, start the silver_cdc stream, and await termination."""
    env = parse_env()
    ensure_objects(env)
    query = run(env)
    _log.info("silver_cdc stream started for env=%s", env.name)
    query.awaitTermination()


if __name__ == "__main__":
    main()
