"""Entrypoint that creates all catalog objects before the streams start."""
from __future__ import annotations

from ..common.bootstrap import ensure_objects
from ..common.logging import get_logger
from ._args import parse_env

_log = get_logger(__name__)


def main() -> None:
    """Create the schema and pipeline tables for the selected environment."""
    env = parse_env()
    ensure_objects(env)
    _log.info("bootstrap complete for env=%s", env.name)


if __name__ == "__main__":
    main()
