"""Entrypoint that ensures target tables exist, launches the demux stream, and blocks."""
from __future__ import annotations

from ..bronze.demux import run
from ..common.bootstrap import ensure_objects
from ..common.logging import get_logger
from ._args import parse_env

_log = get_logger(__name__)


def main() -> None:
    """Ensure objects, start the demux stream, and await termination."""
    env = parse_env()
    ensure_objects(env)
    query = run(env)
    _log.info("demux stream started for env=%s", env.name)
    query.awaitTermination()


if __name__ == "__main__":
    main()
