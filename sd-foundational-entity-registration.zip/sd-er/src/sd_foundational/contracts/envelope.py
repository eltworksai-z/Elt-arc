"""Field paths and helpers for the uniform event envelope shared by all entities."""
from __future__ import annotations

from pyspark.sql import Column
from pyspark.sql import functions as F

ENTITY_TYPE = "event.entityType"
ENTITY_ID = "event.entityId"
EVENT_ID = "event.eventId"
ACTION = "event.action"
TIMESTAMP = "event.timeStamp"
SCHEMA_VERSION = "event.schemaVersionId"
SOURCE = "event.source"
ORIGINATING_SYSTEM_ID = "event.originatingSystemId"
USER = "event.user"

DELETE_ACTIONS = ("delete", "DELETE", "Delete")


def envelope_field(raw_json_col: str, path: str) -> Column:
    """Return a string column extracting an envelope field from a raw JSON column."""
    return F.get_json_object(F.col(raw_json_col), f"$.{path}")


def sequence_ts(col: Column) -> Column:
    """Return the envelope timestamp parsed to a timestamp for ordering."""
    return F.to_timestamp(col)
