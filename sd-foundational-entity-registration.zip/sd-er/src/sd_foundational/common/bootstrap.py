"""Idempotent creation of the catalog schema and pipeline tables with table properties."""
from __future__ import annotations

from . import naming
from .config import EnvConfig, load_entities
from .spark import get_spark


def ensure_objects(env: EnvConfig) -> None:
    """Create the target schema, RAW, reject, typed, and canonical tables if absent."""
    spark = get_spark()
    spark.sql(f"CREATE SCHEMA IF NOT EXISTS {env.catalog}.{env.schema}")

    spark.sql(
        f"""
        CREATE TABLE IF NOT EXISTS {naming.table(env, naming.RAW_LANDING)} (
            kafka_key STRING, payload_raw STRING, kafka_topic STRING,
            kafka_partition INT, kafka_offset LONG, kafka_ts TIMESTAMP,
            entity_type STRING, schema_version STRING, ingest_ts TIMESTAMP
        ) USING DELTA
        """
    )

    spark.sql(
        f"""
        CREATE TABLE IF NOT EXISTS {naming.table(env, naming.RAW_VALIDATED)} (
            kafka_key STRING, kafka_topic STRING, kafka_partition INT, kafka_offset LONG,
            kafka_ts TIMESTAMP, ingest_ts TIMESTAMP, entity_type STRING, schema_version STRING,
            entity_id STRING, event_id STRING, action STRING, event_ts TIMESTAMP,
            source STRING, originating_system_id STRING, user STRING, data_json STRING,
            _dq_warnings ARRAY<STRING>
        ) USING DELTA CLUSTER BY (entity_type, entity_id)
        """
    )

    spark.sql(
        f"""
        CREATE TABLE IF NOT EXISTS {naming.table(env, naming.RAW_REJECTED)} (
            kafka_key STRING, kafka_topic STRING, kafka_partition INT, kafka_offset LONG,
            kafka_ts TIMESTAMP, ingest_ts TIMESTAMP, entity_type STRING, schema_version STRING,
            entity_id STRING, event_id STRING, action STRING, event_ts TIMESTAMP,
            source STRING, originating_system_id STRING, user STRING, data_json STRING,
            payload_raw STRING, reject_stage STRING, reject_reason ARRAY<STRING>
        ) USING DELTA
        """
    )

    spark.sql(
        f"""
        CREATE TABLE IF NOT EXISTS {naming.table(env, naming.CDC_CURRENT)} (
            entity_type STRING, business_key STRING,
            source STRING, originating_system_id STRING, action STRING,
            op STRING, seq_ts TIMESTAMP, event_id STRING, ingest_ts TIMESTAMP,
            attributes VARIANT
        ) USING DELTA
        CLUSTER BY (entity_type, business_key)
        TBLPROPERTIES (delta.enableChangeDataFeed = true)
        """
    )

    for cfg in load_entities():
        spark.sql(
            f"CREATE TABLE IF NOT EXISTS {naming.raw_typed_table(env, cfg.table_name)} "
            f"(entity_id STRING) USING DELTA"
        )
