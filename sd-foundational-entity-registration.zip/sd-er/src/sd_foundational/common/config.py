"""Loading and typed access for environment and per-entity configuration."""
from __future__ import annotations

from dataclasses import dataclass, field
from functools import cache
from importlib import resources

import yaml

_RESOURCES = "sd_foundational.resources"


@dataclass(frozen=True)
class KafkaConfig:
    topic: str
    bootstrap_secret_scope: str
    bootstrap_secret_key: str
    starting_offsets: str
    max_offsets_per_trigger: int
    security_protocol: str | None = None
    extra_options: dict = field(default_factory=dict)


@dataclass(frozen=True)
class StreamingConfig:
    trigger_processing_time: str
    checkpoint_root: str


@dataclass(frozen=True)
class EnvConfig:
    name: str
    catalog: str
    schema: str
    kafka: KafkaConfig
    streaming: StreamingConfig


@dataclass(frozen=True)
class DQRule:
    field: str
    check: str
    severity: str
    args: dict = field(default_factory=dict)


@dataclass(frozen=True)
class EntityConfig:
    entity_type: str
    table_name: str
    schema_version: str
    canonical_mapping: dict
    dq_rules: list


def _read_text(package: str, name: str) -> str:
    """Return the text content of a packaged resource file."""
    return resources.files(package).joinpath(name).read_text(encoding="utf-8")


@cache
def load_env(env: str) -> EnvConfig:
    """Load the environment configuration for the given environment name."""
    raw = yaml.safe_load(_read_text(f"{_RESOURCES}.env", f"{env}.yml"))
    return EnvConfig(
        name=env,
        catalog=raw["catalog"],
        schema=raw["schema"],
        kafka=KafkaConfig(**raw["kafka"]),
        streaming=StreamingConfig(**raw["streaming"]),
    )


@cache
def load_entities() -> tuple:
    """Load every entity configuration bundled under resources/entities."""
    entities = []
    for entry in resources.files(f"{_RESOURCES}.entities").iterdir():
        if entry.name.endswith(".yml"):
            raw = yaml.safe_load(entry.read_text(encoding="utf-8"))
            rules = [DQRule(**r) for r in raw.get("dq_rules", [])]
            entities.append(
                EntityConfig(
                    entity_type=raw["entity_type"],
                    table_name=raw["table_name"],
                    schema_version=str(raw["schema_version"]),
                    canonical_mapping=raw.get("canonical_mapping", {}),
                    dq_rules=rules,
                )
            )
    return tuple(sorted(entities, key=lambda e: e.table_name))


@cache
def entity_by_type() -> dict:
    """Return a mapping from the envelope entityType discriminator to its config."""
    return {e.entity_type: e for e in load_entities()}
