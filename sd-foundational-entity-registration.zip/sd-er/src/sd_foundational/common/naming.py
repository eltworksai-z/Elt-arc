"""Deterministic table and checkpoint naming derived from environment config."""
from __future__ import annotations

from .config import EnvConfig

RAW_LANDING = "raw_landing"
RAW_VALIDATED = "raw_validated"
RAW_REJECTED = "raw_rejected"
CDC_CURRENT = "cdc_current"


def table(env: EnvConfig, name: str) -> str:
    """Return the fully qualified Unity Catalog name for a pipeline table."""
    return f"{env.catalog}.{env.schema}.{name}"


def raw_typed_table(env: EnvConfig, entity_table_name: str) -> str:
    """Return the fully qualified name of a demultiplexed typed RAW table."""
    return table(env, f"raw_{entity_table_name}")


def checkpoint(env: EnvConfig, stream: str) -> str:
    """Return the checkpoint location for a named stream."""
    return f"{env.streaming.checkpoint_root.rstrip('/')}/{stream}"
