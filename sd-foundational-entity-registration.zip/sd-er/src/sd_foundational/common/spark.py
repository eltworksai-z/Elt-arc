"""Spark session and Databricks runtime helpers."""
from __future__ import annotations

from pyspark.sql import SparkSession


def get_spark() -> SparkSession:
    """Return the active Spark session for the current cluster."""
    return SparkSession.builder.getOrCreate()


def get_secret(scope: str, key: str) -> str:
    """Return a secret value resolved through the Databricks secrets utility."""
    from pyspark.dbutils import DBUtils

    dbutils = DBUtils(get_spark())
    return dbutils.secrets.get(scope=scope, key=key)
