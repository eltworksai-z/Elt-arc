"""Git-backed schema registry: JSON Schema contracts, derived Spark structs, validators."""
from __future__ import annotations

import json
from functools import cache
from importlib import resources

import pandas as pd
from jsonschema import Draft202012Validator
from pyspark.sql import functions as F
from pyspark.sql.types import (
    BooleanType,
    DoubleType,
    LongType,
    StringType,
    StructField,
    StructType,
)

_SCHEMAS = "sd_foundational.resources.schemas"

_JSON_TO_SPARK = {
    "string": StringType(),
    "integer": LongType(),
    "number": DoubleType(),
    "boolean": BooleanType(),
}


@cache
def load_json_schema(table_name: str, version: str) -> str:
    """Return the raw JSON Schema text for an entity table name and version."""
    pkg = f"{_SCHEMAS}.{table_name}"
    return resources.files(pkg).joinpath(f"{version}.json").read_text(encoding="utf-8")


@cache
def _schema_dict(table_name: str, version: str) -> dict:
    """Return the parsed JSON Schema document for an entity table name and version."""
    return json.loads(load_json_schema(table_name, version))


@cache
def data_struct(table_name: str, version: str) -> StructType:
    """Return the Spark struct for the data section derived from the JSON Schema."""
    schema = _schema_dict(table_name, version)
    props = schema["properties"]["data"]["properties"]
    fields = []
    for name, spec in props.items():
        spark_type = _JSON_TO_SPARK.get(spec.get("type", "string"), StringType())
        fields.append(StructField(name, spark_type, True))
    return StructType(fields)


def make_schema_validator(table_name: str, version: str):
    """Return a pandas UDF that yields a JSON Schema error string per raw payload."""
    schema = _schema_dict(table_name, version)

    @F.pandas_udf(StringType())
    def _validate(payloads: pd.Series) -> pd.Series:
        validator = Draft202012Validator(schema)

        def check(payload: str) -> str:
            try:
                document = json.loads(payload)
            except (TypeError, ValueError) as exc:
                return f"json_parse:{exc}"
            errors = sorted(validator.iter_errors(document), key=lambda e: list(e.path))
            if not errors:
                return ""
            return "; ".join(
                f"{'/'.join(str(p) for p in e.path) or '<root>'}:{e.message}"
                for e in errors[:5]
            )

        return payloads.map(check)

    return _validate
