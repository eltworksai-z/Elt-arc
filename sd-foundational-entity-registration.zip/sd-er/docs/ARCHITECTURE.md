# Architecture — `sd_foundational.entity_registration`

L1 RAW (Bronze) to canonical Silver medallion pipeline for entity registration
events arriving on a single generic Kafka topic. One topic carries all entity
types; there is no external schema registry, so JSON Schema contracts are
versioned in this repository and enforced at the validation stage.

## Data contract

Every message shares a uniform `event` envelope and an entity-specific `data`
object. The envelope is identical across all entity types, which is why the
business key, sequence, and operation are derived generically and only `data`
needs per-entity schema, mapping, and DQ configuration.

| Envelope field | Pipeline meaning |
|---|---|
| `event.entityType` | Discriminator selecting the entity config and typed table |
| `event.entityId` | Business key for SCD1 identity |
| `event.timeStamp` | Sequence for ordering and the SCD1 merge guard |
| `event.action` | Operation: `create`/`update` upsert, `delete` deletes |
| `event.eventId` | Idempotency identifier |
| `event.schemaVersionId` | Selects the JSON Schema version to validate against |

`data.*` is the entity payload. For `CellLine` it is 51 flat string fields
(see `resources/schemas/cell_line/1.0.2.json`).

## Stage flow

Four independent streaming stages. Each reads its upstream Delta table as a
stream and writes the next, so `raw_validated` fans out to both `demux` and
`silver_cdc` as two separate readers.

```
kafka topic ──▶ raw_landing ──▶ raw_validated ──┬──▶ raw_<entity> × 8 (demux)
                                (+ raw_rejected) └──▶ cdc_current (silver SCD1)
```

| Stage | Entry point | Reads | Writes | Responsibility |
|---|---|---|---|---|
| Ingestion | `ingestion` | Kafka | `raw_landing` | Append raw payload + envelope discriminator, immutable |
| Validation | `validation` | `raw_landing` | `raw_validated`, `raw_rejected` | JSON Schema validation, DQ checks, DLQ with reasons |
| Demux | `demux` | `raw_validated` | `raw_<entity>` (8) | Typed fan-out for other teams |
| Silver CDC | `silver_cdc` | `raw_validated` | `cdc_current` | CDM map, dedup by sequence, guarded SCD1 merge |

## Tables

| Table | Shape | Notes |
|---|---|---|
| `raw_landing` | Raw payload + Kafka metadata + discriminator | Immutable, no parsing of the business body |
| `raw_validated` | Envelope columns + `data_json` + DQ warnings | Unified across types, feeds demux and silver |
| `raw_rejected` | Same + `reject_stage` + `reject_reason[]` | DLQ; `reject_stage` ∈ `schema`/`dq`/`routing` |
| `raw_<entity>` | Typed flattened columns | One per entity type, for downstream teams |
| `cdc_current` | Canonical identity + `attributes` VARIANT | One SCD1 table, Change Data Feed enabled |

## Schema validation

There is no schema registry. `resources/schemas/<table>/<version>.json` holds a
JSON Schema (Draft 2020-12) per entity type and version. Validation resolves the
schema by `(entityType, schemaVersionId)` and validates the whole message. The
`data` object is declared with `additionalProperties: false`, so an unexpected or
missing field is caught and routed to `raw_rejected` with the failing path rather
than being silently dropped. The Spark struct used for typed parsing is derived
from the same JSON Schema, keeping one source of truth.

## Data quality checks

DQ runs after schema validation, on parsed columns. Each entity config lists
rules referencing reusable checks. `error` severity routes the row to
`raw_rejected` with the failing rule; `warn` severity keeps the row and records
the flag in `_dq_warnings`.

| Check | Purpose |
|---|---|
| `not_empty` | Business-critical field is present and non-blank |
| `matches` | Field matches a format regex (e.g. `B-number` pattern) |
| `in_set` | Value is within an allowed domain (action, enums) |
| `is_timestamp` | Field parses as a timestamp against allowed formats |
| `not_future` | Event timestamp is not later than now |

Checks required per entity, at minimum:

- Identity present: `event.entityId`, `data.ID` not empty.
- Key format: `B-number` matches `^B-[0-9]+-[A-Z0-9]+$`.
- Operation valid: `event.action` in `create`/`update`/`delete`.
- Freshness: `event.timeStamp` parses and is not in the future.
- Domain enums as warnings: `Hybridoma Cell Line`, `Externally Sourced`,
  `Clonality`.

Idempotency and out-of-order handling live in the merge, not in DQ: the batch is
reduced to the latest sequence per key, and the merge only writes when
`s.seq_ts > t.seq_ts`, so replays and late arrivals cannot regress a row.

## Repository layout

| Path | Contents |
|---|---|
| `src/sd_foundational/common/` | Config, naming, schema registry, spark and secret helpers, table bootstrap |
| `src/sd_foundational/contracts/` | Envelope field paths and helpers |
| `src/sd_foundational/bronze/` | Ingestion, validation, demux stages |
| `src/sd_foundational/silver/` | CDM mapping and SCD1 CDC merge |
| `src/sd_foundational/dq/` | Reusable checks and the config-driven rule applier |
| `src/sd_foundational/entrypoints/` | One thin `main()` per stage, `--env` argument |
| `src/sd_foundational/resources/env/` | Per-environment config (`prod.yml`) |
| `src/sd_foundational/resources/entities/` | One config per entity type |
| `src/sd_foundational/resources/schemas/` | JSON Schema contracts by entity and version |
| `resources/` | Databricks Asset Bundle job definition |
| `.github/workflows/` | CI (lint + test) and deploy (push to master) |
| `tests/` | Config, schema, and DQ tests with fixtures |
| `samples/` | Real sample payloads |

Entity configs and schemas ship inside the wheel as package data, so the
running job resolves them with `importlib.resources` and they are versioned with
the code.

## Orchestration

Current deployment is one continuous job with four parallel tasks on a shared
cluster (`resources/entity_registration.job.yml`). Continuous jobs cannot use
task dependencies, so the stages are decoupled in the scheduler and ordered only
through the Delta tables. Each entry point calls table bootstrap before starting,
so any stage can start first.

Set the job Task retry mode to **On failure** so a failed task retries in place
with backoff while the other streams keep running.

### Scaling out

A single continuous job restarts all four streams together when new code is
deployed. To restart one stream independently after a fix, split each stage into
its own continuous job drawing workers from a shared instance pool. The stage
code and configuration do not change; only the bundle job definition does.

## Deployment

Single `master` branch. CI runs lint and tests on every push and pull request.
On push to `master`, `deploy.yml` builds the wheel, validates and deploys the
bundle to the `prod` target, then restarts the continuous job so the new wheel is
loaded. Environment values are passed as `BUNDLE_VAR_*` variables from GitHub
Actions variables and secrets; Databricks auth uses `DATABRICKS_HOST` and
`DATABRICKS_TOKEN`.

## Adding an entity type

1. Add `resources/schemas/<table>/<version>.json` with the JSON Schema.
2. Add `resources/entities/<table>.yml` with `entity_type`, `table_name`,
   `schema_version`, `canonical_mapping`, and `dq_rules`.
3. Add a sample under `samples/` and a fixture test.
4. Confirm the `entity_type` string matches the producer's `event.entityType`.

## Open items for the team

- Confirm the seven placeholder discriminator strings in
  `resources/entities/*.yml` (all except `cell_line`) against real payloads, and
  replace the stub schemas with the real field contracts. Until then, those
  types route to `raw_rejected` with `unknown_entity_type`, so nothing is lost.
- Provide the Kafka SASL credentials via the `ede_kafka` secret scope referenced
  in `resources/env/prod.yml`.
