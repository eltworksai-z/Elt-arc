# sd_foundational — entity registration pipeline

Structured Streaming medallion pipeline that ingests entity registration events
from a single generic Kafka topic, validates them against versioned JSON Schema
contracts, and maintains a canonical SCD1 current-state table on Databricks.

See [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) for the full design, the data
contract, the DQ check catalog, and the deployment flow.

## Layout

- `src/sd_foundational/` — pipeline package (bronze, silver, dq, common, contracts, entrypoints)
- `src/sd_foundational/resources/` — env config, entity configs, JSON Schemas (shipped in the wheel)
- `resources/` — Databricks Asset Bundle job
- `.github/workflows/` — CI and deploy
- `tests/`, `samples/` — tests, fixtures, and real sample payloads

## Develop

```bash
pip install -e ".[dev]"
ruff check src tests
pytest -q
```

## Deploy

Push to `master`. CI runs lint and tests; `deploy.yml` builds the wheel and runs
`databricks bundle deploy -t prod`, then restarts the continuous job.

Required GitHub configuration:

- Secrets: `DATABRICKS_HOST`, `DATABRICKS_TOKEN`
- Variables: `CATALOG`, `INSTANCE_POOL_ID`, `DRIVER_INSTANCE_POOL_ID`,
  `SPARK_VERSION`, `MIN_WORKERS`, `MAX_WORKERS`
- Databricks secret scope `ede_kafka` with key `bootstrap_servers`
