"""Tests for JSON Schema validation and derived Spark struct generation."""
import json

from jsonschema import Draft202012Validator

from sd_foundational.common import schemas


def _validator():
    return Draft202012Validator(json.loads(schemas.load_json_schema("cell_line", "1.0.2")))


def test_valid_sample_passes(cell_line_valid):
    errors = list(_validator().iter_errors(cell_line_valid))
    assert errors == []


def test_missing_required_data_field_fails(cell_line_valid):
    del cell_line_valid["data"]["B-number"]
    errors = list(_validator().iter_errors(cell_line_valid))
    assert errors


def test_wrong_entity_type_fails(cell_line_valid):
    cell_line_valid["event"]["entityType"] = "Vector"
    errors = list(_validator().iter_errors(cell_line_valid))
    assert errors


def test_unexpected_data_field_fails(cell_line_valid):
    cell_line_valid["data"]["Injected Field"] = "x"
    errors = list(_validator().iter_errors(cell_line_valid))
    assert errors


def test_data_struct_field_count():
    struct = schemas.data_struct("cell_line", "1.0.2")
    assert len(struct.fields) == 51
