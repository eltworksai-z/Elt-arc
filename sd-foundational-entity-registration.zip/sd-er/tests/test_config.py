"""Tests for environment and entity configuration loading."""
from sd_foundational.common import config


def test_env_loads_prod():
    env = config.load_env("prod")
    assert env.catalog == "sd_foundational"
    assert env.kafka.topic == "ede-registrationsync-generic"


def test_all_entities_have_unique_discriminators():
    entities = config.load_entities()
    types = [e.entity_type for e in entities]
    assert len(types) == len(set(types))
    assert len(entities) == 8


def test_cell_line_registered():
    registry = config.entity_by_type()
    assert "CellLine" in registry
    assert registry["CellLine"].table_name == "cell_line"
