"""Shared pytest fixtures for schema and configuration tests."""
import json
from pathlib import Path

import pytest

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture()
def cell_line_valid() -> dict:
    """Return the parsed valid CellLine sample payload."""
    return json.loads((FIXTURES / "cell_line_valid.json").read_text())
