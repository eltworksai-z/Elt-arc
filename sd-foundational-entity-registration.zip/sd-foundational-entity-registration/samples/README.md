# Samples

Reference Kafka payloads used as test fixtures and as the pattern for onboarding new
entity types.

- `cellline_update.json` — a real `CellLine` update event: the shared `event` envelope
  plus the entity-specific `data` body. Every entity type shares the envelope; only the
  `data` object differs.

Add one sample per entity type as it is onboarded, named `<entity>_<action>.json`.
