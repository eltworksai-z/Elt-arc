"""Creation of the canonical Silver CDC target table."""
from __future__ import annotations

from sd_foundational.common.config import PipelineConfig
from sd_foundational.common.spark_session import get_spark
from sd_foundational.silver.cdm import CANONICAL_COLUMNS

_FIXED_COLUMNS = [
    "entity_id STRING",
    "entity_type STRING",
    "source_system_id STRING",
    "source STRING",
    "operation STRING",
    "event_ts STRING",
    "event_id STRING",
]


def ensure_cdc_current(cfg: PipelineConfig) -> None:
    """Create the unified SCD1 table with CDF and liquid clustering if absent."""
    columns = _FIXED_COLUMNS + [f"{name} STRING" for name in CANONICAL_COLUMNS]
    columns.append("attributes STRING")
    column_ddl = ",\n  ".join(columns)
    get_spark().sql(
        f"""
        CREATE TABLE IF NOT EXISTS {cfg.table("cdc_current")} (
          {column_ddl}
        )
        USING DELTA
        CLUSTER BY (entity_id)
        TBLPROPERTIES (delta.enableChangeDataFeed = true)
        """
    )
