"""Silver CDC stage: unified SCD1 upsert into a single canonical table.

Within each micro-batch the latest event per business key is selected by
sequence, then MERGE applies inserts, updates, and deletes. Every write is
guarded by the sequence so replayed or out-of-order batches cannot regress a row.
"""
from __future__ import annotations

from delta.tables import DeltaTable
from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.streaming import StreamingQuery
from pyspark.sql.window import Window

from sd_foundational.common.config import PipelineConfig
from sd_foundational.common.spark_session import get_spark
from sd_foundational.silver.cdm import to_canonical
from sd_foundational.silver.target import ensure_cdc_current


def latest_per_key(canonical: DataFrame) -> DataFrame:
    """Keep only the highest-sequence event per business key in the batch."""
    ordering = Window.partitionBy("entity_id").orderBy(F.col("event_ts").desc())
    return (
        canonical.withColumn("_rank", F.row_number().over(ordering))
        .filter(F.col("_rank") == 1)
        .drop("_rank")
    )


def merge_scd1(cfg: PipelineConfig, latest: DataFrame) -> None:
    """Apply the SCD1 MERGE with a sequence guard against regressions."""
    target = DeltaTable.forName(get_spark(), cfg.table("cdc_current"))
    (
        target.alias("t")
        .merge(latest.alias("s"), "t.entity_id = s.entity_id")
        .whenMatchedDelete(condition="s.operation = 'delete' AND s.event_ts > t.event_ts")
        .whenMatchedUpdateAll(condition="s.operation = 'upsert' AND s.event_ts > t.event_ts")
        .whenNotMatchedInsertAll(condition="s.operation = 'upsert'")
        .execute()
    )


def process_batch(cfg: PipelineConfig, batch: DataFrame) -> None:
    """Map, deduplicate, and merge one micro-batch into the canonical table."""
    canonical = to_canonical(cfg, batch)
    merge_scd1(cfg, latest_per_key(canonical))


def run(cfg: PipelineConfig) -> StreamingQuery:
    """Start the Silver CDC stream and return the running query."""
    ensure_cdc_current(cfg)
    validated = get_spark().readStream.format("delta").table(cfg.table("raw_validated"))
    return (
        validated.writeStream.option("checkpointLocation", cfg.checkpoint("silver_cdc"))
        .trigger(processingTime=cfg.raw["stream"]["trigger_interval"])
        .foreachBatch(lambda batch, _batch_id: process_batch(cfg, batch))
        .start()
    )
