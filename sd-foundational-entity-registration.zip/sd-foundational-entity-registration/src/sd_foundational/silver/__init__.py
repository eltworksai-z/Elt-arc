"""Silver medallion stages: CDM mapping and SCD1 CDC."""
