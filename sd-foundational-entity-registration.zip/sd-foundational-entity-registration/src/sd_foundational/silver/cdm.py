"""Common Data Model mapping into the unified canonical Silver schema.

Envelope-derived columns are common to every entity type. Type-specific fields
are mapped to canonical columns through the per-entity CDM config, and the full
typed body is preserved as JSON for attributes not present in the common model.
"""
from __future__ import annotations

from functools import reduce

from pyspark.sql import Column, DataFrame
from pyspark.sql import functions as F

from sd_foundational.common.config import PipelineConfig

CANONICAL_COLUMNS = [
    "name",
    "description",
    "project_id",
    "project_name",
    "target_product_id",
    "target_product_name",
    "organization",
    "site",
    "registered_by",
    "registration_date",
    "modified_by",
    "last_modified_date",
]


def _operation(cfg: PipelineConfig, action_col: Column) -> Column:
    """Map a source action to its canonical CDC operation."""
    mapping = cfg.operation_map
    expr = F.lit(None).cast("string")
    for source_action, canonical in mapping.items():
        expr = F.when(F.lower(action_col) == source_action, F.lit(canonical)).otherwise(
            expr
        )
    return expr


def _canonical_for_entity(cfg: PipelineConfig, batch: DataFrame, raw_table: str) -> DataFrame:
    """Project one entity type's rows onto the canonical column set."""
    cdm_map = cfg.cdm_map(raw_table)
    columns = [
        F.col("event")["entityId"].alias("entity_id"),
        F.col("event")["entityType"].alias("entity_type"),
        F.col("event")["originatingSystemId"].alias("source_system_id"),
        F.col("event")["source"].alias("source"),
        _operation(cfg, F.col("event")["action"]).alias("operation"),
        F.col("event")["timeStamp"].alias("event_ts"),
        F.col("event")["eventId"].alias("event_id"),
    ]
    for canonical in CANONICAL_COLUMNS:
        source_field = cdm_map.get(canonical)
        if source_field:
            columns.append(
                F.get_json_object("data_json", f"$['{source_field}']").alias(canonical)
            )
        else:
            columns.append(F.lit(None).cast("string").alias(canonical))
    columns.append(F.col("data_json").alias("attributes"))
    return batch.select(*columns)


def to_canonical(cfg: PipelineConfig, batch: DataFrame) -> DataFrame:
    """Map a mixed-entity batch into the unified canonical Silver schema."""
    parts: list[DataFrame] = []
    for entity in cfg.entities:
        subset = batch.filter(F.col("entity_type") == entity.entity_type)
        parts.append(_canonical_for_entity(cfg, subset, entity.raw_table))
    if not parts:
        return _canonical_for_entity(cfg, batch.limit(0), "")
    return reduce(DataFrame.unionByName, parts)
