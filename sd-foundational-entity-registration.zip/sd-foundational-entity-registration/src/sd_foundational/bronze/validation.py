"""Validation stage: parse each entity type against its contract and run DQ.

Reads the untyped landing stream, and for every entity type present in a batch
parses the body with that type's StructType, applies contract-driven DQ, and
routes passing rows to raw_validated and failing rows to raw_rejected.
"""
from __future__ import annotations

from functools import reduce

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.streaming import StreamingQuery

from sd_foundational.common.config import PipelineConfig
from sd_foundational.common.contracts import load_contract
from sd_foundational.common.spark_session import event_struct, get_spark
from sd_foundational.dq.rules import ERROR_COLUMN, FAILED_COLUMN, apply_dq

_VALIDATED_COLUMNS = [
    "kafka_key",
    "kafka_topic",
    "kafka_partition",
    "kafka_offset",
    "kafka_timestamp",
    "ingest_ts",
    "entity_type",
    "event",
    "data_json",
    "payload_raw",
]


def _parse_envelope(df: DataFrame) -> DataFrame:
    """Attach the parsed event envelope and the raw data body as JSON text."""
    return df.withColumn(
        "event", F.from_json(F.get_json_object("payload_raw", "$.event"), event_struct())
    ).withColumn("data_json", F.get_json_object("payload_raw", "$.data"))


def _resolve_version(cfg: PipelineConfig, entity_type: str) -> str:
    """Return the schema version to apply for an entity type."""
    entity = cfg.entity_by_type(entity_type)
    return entity.default_schema_version if entity else "0.0.0"


def _validate_entity(cfg: PipelineConfig, df: DataFrame, entity_type: str) -> DataFrame:
    """Parse and DQ-check a single entity type, returning a tagged batch."""
    version = _resolve_version(cfg, entity_type)
    contract = load_contract(str(cfg.schema_dir), entity_type, version)
    parsed = df.withColumn("data", F.from_json("data_json", contract.data_struct()))
    return apply_dq(parsed, contract)


def process_batch(cfg: PipelineConfig, batch: DataFrame) -> None:
    """Validate one micro-batch and write the validated and rejected tables."""
    enveloped = _parse_envelope(batch).cache()
    entity_types = [
        row["entity_type"]
        for row in enveloped.select("entity_type").distinct().collect()
        if row["entity_type"] is not None
    ]

    validated_parts: list[DataFrame] = []
    rejected_parts: list[DataFrame] = []

    for entity_type in entity_types:
        subset = enveloped.filter(F.col("entity_type") == entity_type)
        checked = _validate_entity(cfg, subset, entity_type)
        validated_parts.append(
            checked.filter(~F.col(FAILED_COLUMN)).select(*_VALIDATED_COLUMNS)
        )
        rejected_parts.append(
            checked.filter(F.col(FAILED_COLUMN)).select(
                *_VALIDATED_COLUMNS, F.col(ERROR_COLUMN)
            )
        )

    unknown = enveloped.filter(
        ~F.col("entity_type").isin(entity_types) | F.col("entity_type").isNull()
    )
    if unknown.take(1):
        rejected_parts.append(
            unknown.select(*_VALIDATED_COLUMNS).withColumn(
                ERROR_COLUMN, F.array(F.lit("unknown_entity_type"))
            )
        )

    if validated_parts:
        reduce(DataFrame.unionByName, validated_parts).write.format("delta").mode(
            "append"
        ).saveAsTable(cfg.table("raw_validated"))
    if rejected_parts:
        reduce(DataFrame.unionByName, rejected_parts).write.format("delta").mode(
            "append"
        ).saveAsTable(cfg.table("raw_rejected"))

    enveloped.unpersist()


def run(cfg: PipelineConfig) -> StreamingQuery:
    """Start the validation stream and return the running query."""
    landing = get_spark().readStream.format("delta").table(cfg.table("raw_landing"))
    return (
        landing.writeStream.option("checkpointLocation", cfg.checkpoint("raw_validated"))
        .trigger(processingTime=cfg.raw["stream"]["trigger_interval"])
        .foreachBatch(lambda batch, _batch_id: process_batch(cfg, batch))
        .start()
    )
