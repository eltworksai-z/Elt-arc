"""Bronze medallion stages: ingestion, validation, demux."""
