"""Ingestion stage: stream one Kafka topic into the immutable raw_landing table."""
from __future__ import annotations

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.streaming import StreamingQuery

from sd_foundational.common.config import PipelineConfig
from sd_foundational.common.spark_session import get_spark


def read_source(cfg: PipelineConfig, bootstrap_servers: str) -> DataFrame:
    """Open the Kafka source as a stream of raw records."""
    source = cfg.raw["source"]
    return (
        get_spark().readStream.format("kafka")
        .option("kafka.bootstrap.servers", bootstrap_servers)
        .option("subscribe", cfg.topic)
        .option("startingOffsets", source["starting_offsets"])
        .option("maxOffsetsPerTrigger", source["max_offsets_per_trigger"])
        .load()
    )


def to_landing(cfg: PipelineConfig, source: DataFrame) -> DataFrame:
    """Project Kafka records into the landing shape without typing the body."""
    discriminator = cfg.envelope["discriminator"]
    return source.select(
        F.col("key").cast("string").alias("kafka_key"),
        F.col("value").cast("string").alias("payload_raw"),
        F.col("topic").alias("kafka_topic"),
        F.col("partition").alias("kafka_partition"),
        F.col("offset").alias("kafka_offset"),
        F.col("timestamp").alias("kafka_timestamp"),
        F.get_json_object(F.col("value").cast("string"), f"$.event.{discriminator}").alias(
            "entity_type"
        ),
        F.current_timestamp().alias("ingest_ts"),
    )


def run(cfg: PipelineConfig, bootstrap_servers: str) -> StreamingQuery:
    """Start the ingestion stream and return the running query."""
    landing = to_landing(cfg, read_source(cfg, bootstrap_servers))
    return (
        landing.writeStream.format("delta")
        .option("checkpointLocation", cfg.checkpoint("raw_landing"))
        .outputMode("append")
        .trigger(processingTime=cfg.raw["stream"]["trigger_interval"])
        .toTable(cfg.table("raw_landing"))
    )
