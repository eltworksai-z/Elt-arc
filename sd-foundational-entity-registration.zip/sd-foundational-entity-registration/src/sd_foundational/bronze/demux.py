"""Demux stage: split validated rows into one typed RAW table per entity type."""
from __future__ import annotations

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.streaming import StreamingQuery

from sd_foundational.common.config import EntityConfig, PipelineConfig
from sd_foundational.common.contracts import load_contract
from sd_foundational.common.naming import safe_column
from sd_foundational.common.spark_session import get_spark

_ENVELOPE_COLUMNS = [
    F.col("event")["entityId"].alias("entity_id"),
    F.col("event")["action"].alias("action"),
    F.col("event")["timeStamp"].alias("event_ts"),
    F.col("event")["eventId"].alias("event_id"),
    F.col("event")["originatingSystemId"].alias("source_system_id"),
    F.col("event")["source"].alias("source"),
    F.col("ingest_ts"),
]


def _write_entity(cfg: PipelineConfig, batch: DataFrame, entity: EntityConfig) -> None:
    """Parse and flatten one entity type, then append to its typed RAW table."""
    contract = load_contract(
        str(cfg.schema_dir), entity.entity_type, entity.default_schema_version
    )
    data_columns = [
        F.col("data")[field.name].alias(safe_column(field.name))
        for field in contract.fields
    ]
    typed = (
        batch.filter(F.col("entity_type") == entity.entity_type)
        .withColumn("data", F.from_json("data_json", contract.data_struct()))
        .select(*_ENVELOPE_COLUMNS, *data_columns)
    )
    typed.write.format("delta").mode("append").saveAsTable(
        cfg.raw_typed_table(entity.raw_table)
    )


def process_batch(cfg: PipelineConfig, batch: DataFrame) -> None:
    """Write every configured entity type present in one micro-batch."""
    cached = batch.cache()
    for entity in cfg.entities:
        _write_entity(cfg, cached, entity)
    cached.unpersist()


def run(cfg: PipelineConfig) -> StreamingQuery:
    """Start the demux stream and return the running query."""
    validated = get_spark().readStream.format("delta").table(cfg.table("raw_validated"))
    return (
        validated.writeStream.option("checkpointLocation", cfg.checkpoint("demux"))
        .trigger(processingTime=cfg.raw["stream"]["trigger_interval"])
        .foreachBatch(lambda batch, _batch_id: process_batch(cfg, batch))
        .start()
    )
