"""Entrypoint for the Silver CDC stream."""
from __future__ import annotations

from sd_foundational.silver import cdc
from sd_foundational.entrypoints._bootstrap import parse_config


def main() -> None:
    """Start the Silver CDC stream and block until it terminates."""
    cfg, _args = parse_config()
    query = cdc.run(cfg)
    query.awaitTermination()


if __name__ == "__main__":
    main()
