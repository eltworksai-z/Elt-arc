"""Entrypoint for the validation stream."""
from __future__ import annotations

from sd_foundational.bronze import validation
from sd_foundational.entrypoints._bootstrap import parse_config


def main() -> None:
    """Start the validation stream and block until it terminates."""
    cfg, _args = parse_config()
    query = validation.run(cfg)
    query.awaitTermination()


if __name__ == "__main__":
    main()
