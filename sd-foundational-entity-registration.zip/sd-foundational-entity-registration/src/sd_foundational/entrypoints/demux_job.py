"""Entrypoint for the demux stream."""
from __future__ import annotations

from sd_foundational.bronze import demux
from sd_foundational.entrypoints._bootstrap import parse_config


def main() -> None:
    """Start the demux stream and block until it terminates."""
    cfg, _args = parse_config()
    query = demux.run(cfg)
    query.awaitTermination()


if __name__ == "__main__":
    main()
