"""Shared argument parsing and configuration bootstrap for job entrypoints."""
from __future__ import annotations

import argparse

from sd_foundational.common.config import PipelineConfig, load_config


def parse_config(argv: list[str] | None = None) -> tuple[PipelineConfig, argparse.Namespace]:
    """Parse job parameters and return the resolved pipeline configuration."""
    parser = argparse.ArgumentParser()
    parser.add_argument("--catalog", required=True)
    parser.add_argument("--schema", required=True)
    parser.add_argument("--checkpoint-root", required=True)
    parser.add_argument("--conf-dir", required=True)
    parser.add_argument("--schema-dir", required=True)
    parser.add_argument("--bootstrap-servers", default=None)
    args = parser.parse_args(argv)

    cfg = load_config(
        catalog=args.catalog,
        schema=args.schema,
        checkpoint_root=args.checkpoint_root,
        conf_dir=args.conf_dir,
        schema_dir=args.schema_dir,
    )
    return cfg, args
