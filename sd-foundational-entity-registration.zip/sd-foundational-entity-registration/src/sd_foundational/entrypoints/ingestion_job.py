"""Entrypoint for the ingestion stream."""
from __future__ import annotations

from sd_foundational.bronze import ingestion
from sd_foundational.entrypoints._bootstrap import parse_config


def main() -> None:
    """Start the ingestion stream and block until it terminates."""
    cfg, args = parse_config()
    query = ingestion.run(cfg, args.bootstrap_servers)
    query.awaitTermination()


if __name__ == "__main__":
    main()
