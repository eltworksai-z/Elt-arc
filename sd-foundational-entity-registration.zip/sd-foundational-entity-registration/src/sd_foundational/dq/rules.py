"""Data-quality checks compiled from a schema contract into Spark expressions.

Each check contributes zero or more messages to a per-row error array. A row is
rejected when that array is non-empty. Checks run as native column expressions so
the whole batch is evaluated in one pass without Python UDFs.
"""
from __future__ import annotations

from pyspark.sql import Column, DataFrame
from pyspark.sql import functions as F

from sd_foundational.common.contracts import Contract

ERROR_COLUMN = "_dq_errors"
FAILED_COLUMN = "_dq_failed"


def _field(data_col: str, name: str) -> Column:
    """Return the parsed value of a named field within the typed data struct."""
    return F.col(data_col)[name]


def _required_checks(data_col: str, contract: Contract) -> list[Column]:
    """Build checks that reject null or empty values in required fields."""
    checks: list[Column] = []
    for name in contract.required_fields():
        value = _field(data_col, name)
        failed = value.isNull() | (F.trim(value) == F.lit(""))
        checks.append(F.when(failed, F.lit(f"required:{name}")))
    return checks


def _enum_checks(data_col: str, contract: Contract) -> list[Column]:
    """Build checks that reject values outside a field's allowed set."""
    checks: list[Column] = []
    for name, allowed in contract.enum_fields().items():
        value = _field(data_col, name)
        failed = value.isNotNull() & ~value.isin(list(allowed))
        checks.append(F.when(failed, F.lit(f"enum:{name}")))
    return checks


def _pattern_checks(data_col: str, contract: Contract) -> list[Column]:
    """Build checks that reject values not matching a field's pattern."""
    checks: list[Column] = []
    for name, pattern in contract.pattern_fields().items():
        value = _field(data_col, name)
        failed = (
            value.isNotNull()
            & (F.trim(value) != F.lit(""))
            & ~value.rlike(pattern)
        )
        checks.append(F.when(failed, F.lit(f"pattern:{name}")))
    return checks


def _date_checks(data_col: str, contract: Contract) -> list[Column]:
    """Build checks that reject values failing to parse against a date format."""
    checks: list[Column] = []
    for name, fmt in contract.date_fields().items():
        value = _field(data_col, name)
        failed = (
            value.isNotNull()
            & (F.trim(value) != F.lit(""))
            & F.to_date(value, fmt).isNull()
        )
        checks.append(F.when(failed, F.lit(f"date:{name}")))
    return checks


def _envelope_checks(event_col: str, contract: Contract) -> list[Column]:
    """Build checks for required envelope fields and the allowed action set."""
    checks: list[Column] = []
    for name in contract.envelope_required:
        value = F.col(event_col)[name]
        failed = value.isNull() | (F.trim(value) == F.lit(""))
        checks.append(F.when(failed, F.lit(f"envelope_required:{name}")))
    if contract.action_allowed:
        action = F.col(event_col)["action"]
        failed = action.isNotNull() & ~action.isin(list(contract.action_allowed))
        checks.append(F.when(failed, F.lit("envelope_action")))
    return checks


def apply_dq(
    df: DataFrame,
    contract: Contract,
    data_col: str = "data",
    event_col: str = "event",
) -> DataFrame:
    """Attach the DQ error array and failure flag to a parsed batch.

    A null data struct signals a structural parse failure and is marked with a
    single ``parse_failed`` error before value-level checks are applied.
    """
    checks: list[Column] = []
    checks += _envelope_checks(event_col, contract)
    checks += _required_checks(data_col, contract)
    checks += _enum_checks(data_col, contract)
    checks += _pattern_checks(data_col, contract)
    checks += _date_checks(data_col, contract)

    value_errors = F.array_compact(F.array(*checks)) if checks else F.array()
    errors = F.when(
        F.col(data_col).isNull(), F.array(F.lit("parse_failed"))
    ).otherwise(value_errors)

    return df.withColumn(ERROR_COLUMN, errors).withColumn(
        FAILED_COLUMN, F.size(F.col(ERROR_COLUMN)) > 0
    )
