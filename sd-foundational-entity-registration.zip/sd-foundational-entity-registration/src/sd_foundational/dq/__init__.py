"""Contract-driven data-quality checks."""
