"""Shared configuration, contracts, and Spark helpers."""
