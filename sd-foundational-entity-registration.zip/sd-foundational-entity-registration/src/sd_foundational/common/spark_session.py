"""Spark session access and the entity-agnostic event envelope schema."""
from __future__ import annotations

from pyspark.sql import SparkSession
from pyspark.sql.types import StringType, StructField, StructType


def get_spark() -> SparkSession:
    """Return the active Spark session for the running job."""
    return SparkSession.builder.getOrCreate()


def event_struct() -> StructType:
    """Return the schema of the event envelope shared by every entity type."""
    return StructType(
        [
            StructField("action", StringType(), True),
            StructField("entityId", StringType(), True),
            StructField("entityType", StringType(), True),
            StructField("originatingSystemId", StringType(), True),
            StructField("user", StringType(), True),
            StructField("timeStamp", StringType(), True),
            StructField("eventId", StringType(), True),
            StructField("source", StringType(), True),
            StructField("schemaVersionId", StringType(), True),
        ]
    )
