"""Loading and access for the YAML configuration that drives the pipeline."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml


def _read_yaml(path: Path) -> dict[str, Any]:
    """Parse a YAML file into a dictionary."""
    with path.open("r", encoding="utf-8") as handle:
        return yaml.safe_load(handle) or {}


@dataclass(frozen=True)
class EntityConfig:
    """Registry entry mapping one entity type to its typed RAW table."""

    entity_type: str
    raw_table: str
    default_schema_version: str


@dataclass(frozen=True)
class PipelineConfig:
    """Resolved pipeline configuration for a single deployment environment."""

    catalog: str
    schema: str
    checkpoint_root: str
    conf_dir: Path
    schema_dir: Path
    raw: dict[str, Any]
    entities: list[EntityConfig] = field(default_factory=list)

    @property
    def topic(self) -> str:
        """Return the Kafka topic that carries every entity type."""
        return self.raw["source"]["topic"]

    @property
    def envelope(self) -> dict[str, str]:
        """Return the envelope field-name mapping."""
        return self.raw["envelope"]

    @property
    def operation_map(self) -> dict[str, str]:
        """Return the mapping from source action to canonical CDC operation."""
        return self.raw["operation_map"]

    def table(self, key: str) -> str:
        """Return the fully qualified name for a configured logical table."""
        return f"{self.catalog}.{self.schema}.{self.raw['tables'][key]}"

    def raw_typed_table(self, raw_table: str) -> str:
        """Return the fully qualified name for a typed RAW table."""
        return f"{self.catalog}.{self.schema}.raw_{raw_table}"

    def checkpoint(self, stage: str) -> str:
        """Return the checkpoint location for a streaming stage."""
        return f"{self.checkpoint_root.rstrip('/')}/{stage}"

    def entity_by_type(self, entity_type: str) -> EntityConfig | None:
        """Return the registry entry for an entity type when it exists."""
        return next((e for e in self.entities if e.entity_type == entity_type), None)

    def cdm_map(self, raw_table: str) -> dict[str, str]:
        """Return the canonical column mapping for a typed table."""
        path = self.conf_dir / "cdm" / f"{raw_table}.yml"
        if not path.exists():
            return {}
        return _read_yaml(path).get("canonical", {})


def _conf_root() -> Path:
    """Return the configuration directory, overridable for tests and jobs."""
    return Path(os.environ.get("SD_CONF_DIR", "/Workspace/conf")).resolve()


def _schema_root() -> Path:
    """Return the schema-contract directory, overridable for tests and jobs."""
    return Path(os.environ.get("SD_SCHEMA_DIR", "/Workspace/schemas")).resolve()


@lru_cache(maxsize=8)
def load_config(
    catalog: str,
    schema: str,
    checkpoint_root: str,
    conf_dir: str | None = None,
    schema_dir: str | None = None,
) -> PipelineConfig:
    """Load and cache the full pipeline configuration for one environment."""
    conf_path = Path(conf_dir).resolve() if conf_dir else _conf_root()
    schema_path = Path(schema_dir).resolve() if schema_dir else _schema_root()

    pipeline = _read_yaml(conf_path / "pipeline.yml")
    entities_raw = _read_yaml(conf_path / "entities.yml").get("entities", [])
    entities = [
        EntityConfig(
            entity_type=item["entity_type"],
            raw_table=item["raw_table"],
            default_schema_version=str(item["default_schema_version"]),
        )
        for item in entities_raw
    ]

    return PipelineConfig(
        catalog=catalog,
        schema=schema,
        checkpoint_root=checkpoint_root,
        conf_dir=conf_path,
        schema_dir=schema_path,
        raw=pipeline,
        entities=entities,
    )
