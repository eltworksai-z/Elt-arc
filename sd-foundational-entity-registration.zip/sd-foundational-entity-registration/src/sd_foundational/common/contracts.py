"""Schema contracts: the single source of truth for parse structure and DQ."""
from __future__ import annotations

import json
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any

from pyspark.sql.types import (
    BooleanType,
    DataType,
    DoubleType,
    LongType,
    StringType,
    StructField,
    StructType,
    TimestampType,
)

_SPARK_TYPES: dict[str, DataType] = {
    "string": StringType(),
    "long": LongType(),
    "double": DoubleType(),
    "boolean": BooleanType(),
    "timestamp": TimestampType(),
    "date": StringType(),
}


@dataclass(frozen=True)
class FieldSpec:
    """Declared type and constraints for a single data field."""

    name: str
    type: str
    required: bool
    enum: tuple[str, ...] | None
    pattern: str | None
    date_format: str | None


@dataclass(frozen=True)
class Contract:
    """Parsed schema contract for one entity type and schema version."""

    entity_type: str
    version: str
    envelope_required: tuple[str, ...]
    action_allowed: tuple[str, ...]
    fields: tuple[FieldSpec, ...]

    def data_struct(self) -> StructType:
        """Build the Spark StructType used to parse the typed data body."""
        return StructType(
            [StructField(f.name, _SPARK_TYPES[f.type], True) for f in self.fields]
        )

    def required_fields(self) -> tuple[str, ...]:
        """Return the names of fields that must carry a non-empty value."""
        return tuple(f.name for f in self.fields if f.required)

    def enum_fields(self) -> dict[str, tuple[str, ...]]:
        """Return fields constrained to a fixed set of allowed values."""
        return {f.name: f.enum for f in self.fields if f.enum}

    def pattern_fields(self) -> dict[str, str]:
        """Return fields constrained by a regular expression."""
        return {f.name: f.pattern for f in self.fields if f.pattern}

    def date_fields(self) -> dict[str, str]:
        """Return fields that must parse against a declared date format."""
        return {f.name: f.date_format for f in self.fields if f.date_format}


def _to_field_spec(name: str, raw: dict[str, Any]) -> FieldSpec:
    """Convert one contract field entry into a FieldSpec."""
    enum = raw.get("enum")
    return FieldSpec(
        name=name,
        type=raw.get("type", "string"),
        required=bool(raw.get("required", False)),
        enum=tuple(enum) if enum is not None else None,
        pattern=raw.get("pattern"),
        date_format=raw.get("date_format"),
    )


@lru_cache(maxsize=64)
def load_contract(schema_dir: str, entity_type: str, version: str) -> Contract:
    """Load and cache the schema contract for an entity type and version."""
    path = Path(schema_dir) / entity_type / f"{version}.json"
    with path.open("r", encoding="utf-8") as handle:
        raw = json.load(handle)

    envelope = raw.get("envelope", {})
    fields = tuple(
        _to_field_spec(name, spec) for name, spec in raw.get("fields", {}).items()
    )
    return Contract(
        entity_type=raw["entity_type"],
        version=str(raw["version"]),
        envelope_required=tuple(envelope.get("required", [])),
        action_allowed=tuple(envelope.get("action_allowed", [])),
        fields=fields,
    )
