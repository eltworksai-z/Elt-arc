"""Normalization of source field names into safe Delta column names."""
from __future__ import annotations

import re

_NON_ALNUM = re.compile(r"[^0-9a-z]+")


def safe_column(name: str) -> str:
    """Convert a source field name into a lowercase snake_case column name."""
    collapsed = _NON_ALNUM.sub("_", name.lower())
    return collapsed.strip("_")
