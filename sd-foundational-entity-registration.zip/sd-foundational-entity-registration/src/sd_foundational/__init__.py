"""Foundational entity-registration streaming pipeline."""
