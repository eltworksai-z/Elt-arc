# Deployment

## Branching and environments

There is one long-lived branch: `master`. Environments are separated by bundle
targets, not branches. `dev` and `prod` are declared in `databricks.yml`; the same code
deploys to either by changing the target. Pull requests validate against `dev`; merges
to `master` deploy.

## CI/CD

`.github/workflows/deploy.yml` runs on pull requests and pushes to `master`.

- On a pull request: `databricks bundle validate -t dev`.
- On a push to `master`: `databricks bundle deploy -t prod --auto-approve`.
- Manual `workflow_dispatch` allows choosing `dev` or `prod`.

Authentication is GitHub OIDC to a Databricks service principal — no PATs are stored.
The workflow requests an ID token (`id-token: write`), and the CLI exchanges it using
`DATABRICKS_AUTH_TYPE=github-oidc` with `DATABRICKS_CLIENT_ID`.

### GitHub Environment configuration

Create GitHub Environments named `dev` and `prod`. Add protection rules (required
reviewers) on `prod`. Set these Environment variables in each:

| Variable               | Meaning                                        |
|------------------------|------------------------------------------------|
| DATABRICKS_HOST        | Workspace URL                                  |
| SERVICE_PRINCIPAL_ID   | Service principal application (client) ID      |
| BOOTSTRAP_SERVERS      | Kafka bootstrap servers                        |
| INSTANCE_POOL_ID       | Instance pool ID for the job cluster           |

Register the workspace as an OIDC federation target for the service principal so the
token exchange is accepted.

## Instance pool

The job cluster draws nodes from an instance pool for fast, warm starts. Create the pool
once per workspace (UI, Terraform, or the pools API), fixing the node type and a
minimum idle count that balances warm-start latency against idle cost. All clusters in
the pool share the node type and Databricks Runtime version. Pass its ID as
`INSTANCE_POOL_ID`.

## Kafka credentials

Provide `bootstrap_servers` as an environment variable. Supply SASL/TLS credentials via
a Databricks secret scope and reference them from the ingestion cluster's Spark
configuration rather than committing them.

## Current topology and scale-out

The current phase runs all four streams as parallel tasks in one continuous job on one
shared pooled cluster. This is the simplest correct topology.

To scale out, split each stream into its own continuous job. This gives each stream an
independent restart lifecycle: after a code fix you redeploy and restart only the
affected job, while the others keep running from their checkpoints. The stream code and
configuration do not change — only the bundle's job resources. Because streams
communicate through Delta tables, separating jobs does not affect correctness.
