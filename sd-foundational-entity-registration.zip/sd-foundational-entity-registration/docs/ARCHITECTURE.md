# Architecture

## Source shape

One Kafka topic (`ede-registrationsync-generic`) carries every entity type. There is
no schema registry service. Each message is an envelope plus a typed body:

```
{ "event": { ...metadata... }, "data": { ...entity-type-specific... } }
```

The `event.entityType` field is the discriminator. Because it lives in the envelope,
ingestion and demux route on it without parsing the typed body.

Envelope fields used by the pipeline:

| Field                  | Role                                    |
|------------------------|-----------------------------------------|
| entityType             | Routing discriminator                   |
| entityId               | Business key for SCD1                    |
| timeStamp              | Sequence for dedup and merge guard       |
| action                 | CDC operation (create/update/delete)    |
| eventId                | Idempotency key                          |
| schemaVersionId        | Selects the schema contract version      |
| originatingSystemId    | Source system reference                  |

## Medallion flow

`raw_landing` keeps payloads untyped and immutable, so a schema change at the source
never breaks ingestion. `raw_validated` holds the parsed envelope, the raw data body,
and a validation verdict, and is the single source for both fan-outs. `demux` produces
eight typed RAW tables for other teams. `silver_cdc` maps all types into one canonical
SCD1 table.

## Orchestration

Four independent Structured Streaming queries, each with `Trigger.ProcessingTime`.
Streams are not chained as dependent tasks — a streaming task never completes, so a
`depends_on` on it would never start. Ordering is enforced by the Delta tables.

For the current phase all four run as parallel tasks in one continuous job on a shared
pooled cluster. The design scales to one continuous job per stream when independent
restart-after-code-fix is required; see DEPLOYMENT.md.

## SCD1 merge

Within each micro-batch the newest event per `entity_id` is selected by sequence, then
MERGE applies the change. Every matched clause is guarded by `s.event_ts > t.event_ts`
so out-of-order or replayed batches cannot regress a row, which makes the stream
idempotent across restarts. `cdc_current` has Change Data Feed enabled for downstream
consumers and is liquid-clustered by `entity_id`.

## Delivery semantics

`foreachBatch` is at-least-once: a batch can be re-executed after a mid-batch failure.
The Silver merge is idempotent because it is guarded by sequence, so re-execution cannot
double-apply. The demux append tables are not inherently idempotent on retry; if strict
exactly-once is required there, make the batch write idempotent with `txnAppId` and
`txnVersion`, or replace the append with a MERGE keyed on `event_id`.

## Ordering assumption

Sequencing uses `event.timeStamp` compared as an ISO-8601 UTC string. This is correct
while the source emits a consistent timestamp format. If formats ever diverge, switch
the sequence to a parsed timestamp in `cdm.py` and `cdc.py`.

## Unified canonical table

`cdc_current` is one table for all entity types: envelope-derived columns, a set of
common canonical columns mapped per type through `conf/cdm/`, and an `attributes` column
holding the full typed body for fields outside the common model. If per-type canonical
tables are preferred later, the merge key and target become per entity type; the CDM
mapping layer stays the same.

## Alternative: Lakeflow Declarative Pipelines

`AUTO CDC` (`apply_changes`) provides SCD1 dedup-by-sequence and MERGE natively, and
`@expect` rules cover DQ with automatic quarantine. It manages stream lifecycle and
checkpoints. The tradeoff is less control over the exact MERGE. This repository keeps
the explicit merge for full control; the Silver hop is the natural place to evaluate a
switch.
