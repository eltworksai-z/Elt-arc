# Data quality

Validation happens in two layers in the `validation` stream. Every failure routes the
row to `raw_rejected` with a `_dq_errors` array naming each broken rule, so quarantine
is queryable and nothing is silently dropped.

## Layer 1: structural (schema)

The typed body is parsed with the contract's StructType. A body that does not parse
yields a null struct and is rejected with `parse_failed`. This catches malformed JSON
and gross type mismatches before any value-level check runs.

## Layer 2: value-level (contract-driven)

Each check is declared in the schema contract and compiled to a native column
expression, so a whole batch is evaluated in one pass with no Python UDFs.

| Check                | Contract key   | Rejects when                                        |
|----------------------|----------------|-----------------------------------------------------|
| Envelope required    | envelope.required | An envelope field is null or blank               |
| Envelope action      | action_allowed | `action` is outside the allowed set                 |
| Required field       | `required`     | A required data field is null or blank              |
| Enum membership      | `enum`         | A value is outside its allowed set                  |
| Pattern              | `pattern`      | A non-blank value fails its regular expression       |
| Date parse           | `date_format`  | A non-blank value fails to parse against the format  |
| Unknown entity type  | registry       | `entityType` is absent from `conf/entities.yml`     |

## Required checks for this source

These are the minimum recommended for the entity-registration source:

- Envelope completeness: `entityId`, `entityType`, `timeStamp`, `eventId`,
  `schemaVersionId`, `action` must be present. Without these the row cannot be routed,
  sequenced, or merged.
- Action domain: `action` restricted to create/update/delete.
- Business-key format: `B-number` matched against its pattern.
- Controlled vocabularies: fields such as `Clonality`, `Hybridoma Cell Line`,
  `Externally Sourced`, `Created With Production Plate` constrained to their enums.
- Date fields: `Transfection Date` parseable against its declared format.
- Known entity type: rows whose `entityType` is not registered are quarantined rather
  than parsed against a guessed schema.

## Recommended operational checks

Beyond per-row rules, monitor at the batch level:

- Rejection rate per entity type, alerting when it crosses a threshold.
- Duplicate `eventId` volume, indicating source or replay anomalies.
- Late-arrival volume relative to the configured watermark.
- Row-count parity between `raw_validated` and the demux tables.

For a managed rule framework, Databricks Labs DQX or Lakeflow `@expect` expectations
can replace the in-repo engine without changing the contracts.

## Cross-batch de-duplication

If the source can redeliver the same `eventId`, enable watermarked de-duplication on
`(entityId, eventId)` in the validation stream using the configured `watermark`. The
within-batch dedup in Silver handles ordering; the watermarked dedup handles redelivery
across batches. Choose deliberately — unbounded `dropDuplicates` grows state forever.
