# Repository structure

Everything that varies per entity type lives in configuration. The Python code is
generic and does not change when an entity type is added. Onboarding a new entity
type means adding a registry row, a schema contract, and an optional CDM map — no
code edit.

```
sd-foundational-entity-registration/
├── databricks.yml                     Bundle root: variables + dev/prod targets
├── resources/
│   └── entity_registration.job.yml    One continuous job, four parallel streaming tasks
├── conf/                              Runtime configuration synced to the workspace
│   ├── pipeline.yml                   Topic, envelope field map, operation map, trigger, tables
│   ├── entities.yml                   Registry: entity_type -> typed RAW table + schema version
│   └── cdm/
│       └── cell_line.yml              Canonical column mapping for one entity type
├── schemas/                          Git-versioned schema registry (no external service)
│   └── CellLine/
│       └── 1.0.2.json                Contract: field types + DQ constraints for one version
├── src/sd_foundational/
│   ├── common/
│   │   ├── config.py                 Loads YAML config; resolves table and checkpoint names
│   │   ├── contracts.py              Turns a contract file into a StructType and DQ rule sets
│   │   └── spark_session.py          Spark session accessor and the shared event envelope schema
│   ├── dq/
│   │   └── rules.py                  Contract-driven DQ compiled to native column expressions
│   ├── bronze/
│   │   ├── ingestion.py              Kafka  -> raw_landing (untyped, immutable)
│   │   ├── validation.py             raw_landing -> raw_validated (+ raw_rejected)
│   │   └── demux.py                  raw_validated -> one typed RAW table per entity type
│   ├── silver/
│   │   ├── cdm.py                    Maps every entity type into the unified canonical shape
│   │   ├── target.py                 Creates cdc_current with CDF and liquid clustering
│   │   └── cdc.py                    Dedup latest sequence per key, then SCD1 MERGE
│   └── entrypoints/
│       ├── _bootstrap.py             Parses job parameters into a resolved config
│       ├── ingestion_job.py          Task entry point: ingestion
│       ├── validation_job.py         Task entry point: validation
│       ├── demux_job.py              Task entry point: demux
│       └── silver_cdc_job.py         Task entry point: Silver CDC
├── tests/                            Transform-level tests on a local Spark session
├── samples/                          Reference Kafka payloads used as fixtures
├── .github/workflows/deploy.yml      Validate on PR, deploy on push to master via OIDC
└── pyproject.toml                    Package metadata and console-script entry points
```

## The four streams

Each stream is an independent, always-on query. They are decoupled in the scheduler
(no task dependencies) and coupled only through their Delta tables: a downstream
stream reads the upstream table as a streaming source.

| Stream      | Reads            | Writes                          | Key operation                         |
|-------------|------------------|---------------------------------|---------------------------------------|
| ingestion   | Kafka topic      | raw_landing                     | Keep payload raw, extract entity_type |
| validation  | raw_landing      | raw_validated, raw_rejected     | Parse per contract, run DQ, split     |
| demux       | raw_validated    | raw_<entity> (one per type)     | Filter, flatten, append               |
| silver_cdc  | raw_validated    | cdc_current                     | Dedup by sequence, SCD1 MERGE         |

## Adding an entity type

1. Add a row to `conf/entities.yml` with its `entity_type` and `raw_table`.
2. Add a contract at `schemas/<EntityType>/<version>.json`.
3. Add `conf/cdm/<raw_table>.yml` if any type fields map to canonical columns.

No change to any Python module is required.
