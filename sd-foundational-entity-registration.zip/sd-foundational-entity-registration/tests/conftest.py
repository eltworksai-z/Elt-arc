"""Shared pytest fixtures for the pipeline test suite."""
from __future__ import annotations

from pathlib import Path

import pytest
from pyspark.sql import SparkSession

REPO_ROOT = Path(__file__).resolve().parents[1]
CONF_DIR = REPO_ROOT / "conf"
SCHEMA_DIR = REPO_ROOT / "schemas"


@pytest.fixture(scope="session")
def spark() -> SparkSession:
    """Return a local Spark session for the test session."""
    session = (
        SparkSession.builder.master("local[2]")
        .appName("sd-foundational-tests")
        .config("spark.sql.shuffle.partitions", "2")
        .getOrCreate()
    )
    yield session
    session.stop()


@pytest.fixture()
def config():
    """Return a pipeline config bound to the in-repo conf and schema dirs."""
    from sd_foundational.common.config import load_config

    return load_config(
        catalog="test_catalog",
        schema="entity_registration",
        checkpoint_root="/tmp/checkpoints",
        conf_dir=str(CONF_DIR),
        schema_dir=str(SCHEMA_DIR),
    )
