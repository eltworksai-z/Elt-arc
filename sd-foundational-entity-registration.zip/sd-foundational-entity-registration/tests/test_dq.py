"""Tests for the contract-driven data-quality engine."""
from __future__ import annotations

import json

from pyspark.sql import functions as F

from sd_foundational.common.contracts import load_contract
from sd_foundational.common.spark_session import event_struct
from sd_foundational.dq.rules import FAILED_COLUMN, apply_dq
from tests.conftest import REPO_ROOT, SCHEMA_DIR

SAMPLE = REPO_ROOT / "samples" / "cellline_update.json"


def _prepared(spark, payload: dict):
    """Return a one-row batch parsed into event and typed data columns."""
    contract = load_contract(str(SCHEMA_DIR), "CellLine", "1.0.2")
    raw = json.dumps(payload)
    df = spark.createDataFrame([(raw,)], ["payload_raw"])
    df = df.withColumn(
        "event", F.from_json(F.get_json_object("payload_raw", "$.event"), event_struct())
    ).withColumn("data_json", F.get_json_object("payload_raw", "$.data"))
    df = df.withColumn("data", F.from_json("data_json", contract.data_struct()))
    return apply_dq(df, contract), contract


def test_valid_row_passes(spark):
    """The reference sample passes all contract checks."""
    payload = json.loads(SAMPLE.read_text())
    checked, _ = _prepared(spark, payload)
    assert checked.select(FAILED_COLUMN).first()[0] is False


def test_missing_required_is_rejected(spark):
    """A blank required field is rejected with a required-field error."""
    payload = json.loads(SAMPLE.read_text())
    payload["data"]["Merck Name"] = ""
    checked, _ = _prepared(spark, payload)
    row = checked.select(FAILED_COLUMN, "_dq_errors").first()
    assert row[0] is True
    assert "required:Merck Name" in row[1]


def test_bad_enum_is_rejected(spark):
    """A value outside the allowed enum set is rejected."""
    payload = json.loads(SAMPLE.read_text())
    payload["data"]["Clonality"] = "Mixture"
    checked, _ = _prepared(spark, payload)
    assert "enum:Clonality" in checked.select("_dq_errors").first()[0]


def test_bad_pattern_is_rejected(spark):
    """A B-number not matching the pattern is rejected."""
    payload = json.loads(SAMPLE.read_text())
    payload["data"]["B-number"] = "not-a-b-number"
    checked, _ = _prepared(spark, payload)
    assert "pattern:B-number" in checked.select("_dq_errors").first()[0]
