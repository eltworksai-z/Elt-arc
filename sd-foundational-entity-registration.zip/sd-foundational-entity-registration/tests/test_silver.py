"""Tests for CDM mapping and Silver dedup logic."""
from __future__ import annotations

import json

from pyspark.sql import functions as F

from sd_foundational.common.spark_session import event_struct
from sd_foundational.silver.cdc import latest_per_key
from sd_foundational.silver.cdm import to_canonical
from tests.conftest import REPO_ROOT

SAMPLE = REPO_ROOT / "samples" / "cellline_update.json"


def _validated(spark, payloads):
    """Return a batch shaped like raw_validated for the given payloads."""
    rows = [(json.dumps(p),) for p in payloads]
    df = spark.createDataFrame(rows, ["payload_raw"])
    return (
        df.withColumn(
            "event",
            F.from_json(F.get_json_object("payload_raw", "$.event"), event_struct()),
        )
        .withColumn("data_json", F.get_json_object("payload_raw", "$.data"))
        .withColumn("entity_type", F.col("event")["entityType"])
    )


def test_canonical_maps_common_and_type_fields(spark, config):
    """Canonical output carries envelope columns and mapped type fields."""
    payload = json.loads(SAMPLE.read_text())
    canonical = to_canonical(config, _validated(spark, [payload]))
    row = canonical.first().asDict()
    assert row["entity_id"] == "B-110027934-000J"
    assert row["operation"] == "upsert"
    assert row["name"] == "celling-asdaas"
    assert row["target_product_id"] == "TPP-540"
    assert json.loads(row["attributes"])["Project ID"] == "PRJ-40"


def test_latest_per_key_keeps_highest_sequence(spark, config):
    """Dedup retains only the newest event for a business key."""
    older = json.loads(SAMPLE.read_text())
    newer = json.loads(SAMPLE.read_text())
    older["event"]["timeStamp"] = "2026-08-05T09:03:08.000000000Z"
    newer["event"]["timeStamp"] = "2026-08-05T10:00:00.000000000Z"
    newer["data"]["Merck Name"] = "renamed"

    canonical = to_canonical(config, _validated(spark, [older, newer]))
    latest = latest_per_key(canonical)
    assert latest.count() == 1
    assert latest.first()["name"] == "renamed"
