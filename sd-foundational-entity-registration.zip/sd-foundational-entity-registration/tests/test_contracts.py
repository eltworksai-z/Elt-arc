"""Tests for configuration loading and schema-contract compilation."""
from __future__ import annotations

from sd_foundational.common.contracts import load_contract
from tests.conftest import SCHEMA_DIR


def test_entity_registry_is_loaded(config):
    """The entity registry exposes the CellLine typed table."""
    entity = config.entity_by_type("CellLine")
    assert entity is not None
    assert entity.raw_table == "cell_line"
    assert config.raw_typed_table("cell_line").endswith(".raw_cell_line")


def test_contract_builds_struct_and_rules():
    """The CellLine contract yields a struct and the expected constraint sets."""
    contract = load_contract(str(SCHEMA_DIR), "CellLine", "1.0.2")
    struct = contract.data_struct()

    assert len(struct.fields) == len(contract.fields)
    assert "B-number" in contract.required_fields()
    assert contract.enum_fields()["Clonality"] == ("Pool", "Clonal", "")
    assert contract.pattern_fields()["B-number"].startswith("^B-")
    assert "Transfection Date" in contract.date_fields()


def test_envelope_requirements_present():
    """The contract carries the required envelope fields and allowed actions."""
    contract = load_contract(str(SCHEMA_DIR), "CellLine", "1.0.2")
    assert "eventId" in contract.envelope_required
    assert set(contract.action_allowed) == {"create", "update", "delete"}
