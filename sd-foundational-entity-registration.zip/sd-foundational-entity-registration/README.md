# Foundational Entity Registration

Structured Streaming medallion pipeline that ingests foundational entity-registration
events from one Kafka topic and lands them as validated RAW tables and a unified,
change-tracked canonical table.

One topic carries all entity types. There is no schema-registry service — schema
contracts are versioned in this repository under `schemas/`.

## Flow

```
Kafka topic
   -> ingestion    -> raw_landing        (untyped, immutable)
   -> validation   -> raw_validated      (parsed + DQ passed)
                      raw_rejected        (quarantine with error reasons)
   -> demux        -> raw_<entity>        (one typed table per entity type)
   -> silver_cdc   -> cdc_current         (unified SCD1, Change Data Feed on)
```

Four independent always-on streams, decoupled in the scheduler and coupled through
their Delta tables. See `docs/ARCHITECTURE.md`.

## Layout

The code is generic; everything entity-specific is configuration. Adding an entity type
is a registry row plus a schema contract, with no code change. See `docs/STRUCTURE.md`.

## Quickstart

```bash
pip install -e ".[test]"
pytest
databricks bundle validate -t dev
databricks bundle deploy -t dev
```

Deployment, environments, and CI/CD are in `docs/DEPLOYMENT.md`. Data-quality rules are
in `docs/DATA_QUALITY.md`.

## Configuration

| File                  | Purpose                                              |
|-----------------------|------------------------------------------------------|
| conf/pipeline.yml     | Topic, envelope mapping, operation map, trigger      |
| conf/entities.yml     | Entity registry: type -> typed table + version       |
| conf/cdm/<table>.yml  | Canonical column mapping per entity type             |
| schemas/<Type>/<v>.json | Schema contract driving parse and DQ               |

## Onboarding the remaining entity types

`CellLine` is fully defined from a real payload. The registry also lists
`CellLineBatch`, `Vector`, and `Ppt`; add their schema contracts and CDM maps, plus the
rest of the eight types, following the `CellLine` files as the pattern. Confirm each
`entity_type` string exactly matches the value the source emits in `event.entityType`.
